# Launch plaza — design prototype

## Implemented

- Original stud-style spawn model in `assets/LaunchPlaza.rbxmx`.
- 369 anchored native Roblox parts, including a neutral SpawnLocation.
- Green checkerboard grass, brown stud cliffs, block trees, glowing cube pumpkins.
- Orange circulation path, welcome mascot, blue/orange cannon and flight-ring vista.
- Egg and upgrade kiosks; leaderboard design panels with explicit coming-soon text.
- Workspace mapping preserves instances outside `Workspace/LaunchPlaza`.
- Reproducible model generator: `python3 tools/build_spawn.py`.
- Cross-platform verified Rojo downloader and local synchronization helper.

## Verified in the cloud

- Rojo 7.7.1 download SHA-256 matches the official release digest.
- Place build succeeds with the generated model.
- Rojo server starts and its MessagePack discovery/read API responds.
- Built place contains the server, client and shared module scripts.

## Not verified / not implemented

- No Roblox Studio connection exists in this session; no Studio screenshot or
  playtest, device performance test or local plugin installation was performed.
- The artwork is a design concept, not a screenshot of the built model.
- Launch simulation, rewards, pet inventory, hatching, upgrades and live rankings
  are not implemented. The uploaded master document provides wider game context;
  the current deliverable is the requested themed spawn and design.
- Nothing has been pushed, published or installed into an existing local game.

## Next local step

Follow README.md to install the Rojo plugin and serve the local repository.
Test in a blank place first. Inspect spawn clearance, sign orientation, stud
rendering and camera views, then run Studio Play. Before syncing an existing game,
save a copy and inspect Rojo's proposed changes. Objects within `LaunchPlaza` and
the three `Roblox1` script folders are owned by this project.
