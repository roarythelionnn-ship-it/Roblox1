# Lokal mit diesem Arbeitsstand weitermachen

## Aktuelle Spiel-Datei

`LaunchYourMonster-Updated.rbxlx` ist die überarbeitete Kopie deiner hochgeladenen
Spiel-Datei. In Studio über **Datei → Aus Datei öffnen** öffnen. Die ursprüngliche
Datei wurde nicht verändert. Dies ist ein Entwicklungsstand, kein vollständig
in Roblox Studio abgenommener Release.

## Studio mit deinem lokalen KI-Client verbinden

Nach der aktuellen offiziellen Anleitung:
https://create.roblox.com/docs/studio/mcp

1. Aktuelles Roblox Studio öffnen und die überarbeitete Datei laden.
2. **Assistant → ⋯ → Manage MCP Servers** öffnen.
3. **Enable Studio as MCP server** einschalten.
4. Unter **Quick connect** den lokal installierten Client aktivieren:
   **Claude Desktop** oder **Codex CLI**.
5. Den Client neu starten und die grüne Verbindungsanzeige in Studio prüfen.

Diese lokale Verbindung verbindet nicht automatisch die bisherige Cloud-Sitzung.
Wenn ein Desktop-Client dort nicht angeboten wird, hat er dadurch noch keine
Studio-Verbindung. Keine EXE-Pfade, Zugangs-Token oder Studio-IDs erfinden.

## Übergabe-Prompt für einen neuen lokalen Chat

> Übernimm den Arbeitsstand LAUNCH YOUR MONSTER! aus dem entpackten Paket.
> Lies zuerst docs/UPDATED_GAME_STATUS.md, docs/CREATURE_ART.md und README.md.
> Die Datei LaunchYourMonster-Updated.rbxlx ist bereits in Studio geöffnet.
> Nutze die verfügbaren Roblox-Studio-MCP-Werkzeuge: Liste zuerst die verbundenen
> Studios und wähle die passende studio_id. Inspiziere die Spielstruktur vor
> Änderungen. Teste zuerst den vorhandenen Stand statt ihn neu zu erzeugen.
> Prüfe Spawn, GUI, Auf-/Absteigen, normales Reiten und einen vollständigen
> Kanonenflug mit sitzendem Spieler, Boost, Landung und sofortigem Retry.
> Prüfe Output und mach einen Screenshot. Teste danach Handy-Layout,
> Weltwechsel/Respawn und zwei Spieler. Die Original-Tiergeometrien stammen aus
> art-source/showcase-engine.js und assets/exact_creatures.json; native Modelle
> sind Ersatzmodelle. Kontrolliere AssetModels.ExactArtStatus auf dem Client,
> bevor du behauptest, dass die Originalmeshes sichtbar sind. Lade keine
> erfundenen Asset-IDs und veröffentliche nichts. Melde echte Testergebnisse
> auf Deutsch und arbeite autonom an konkreten Fehlern weiter.

## Original-Tiere und Mesh-API

Die Datei enthält die tatsächlichen exportierten Geometrien aller 16 Tiere.
Der Client versucht, daraus lokale EditableMesh-Modelle aufzubauen. Das vermeidet
es, eine automatische Replikation dynamischer Mesh-Inhalte vorauszusetzen.
Bodenreittiere erhalten bei Erfolg eine lokale Originalmodell-Darstellung;
Flugmodelle und neue Inventaransichten verwenden die aktualisierten Vorlagen.
Die ersten bereits geöffneten Vorschauen können bis zum erneuten Öffnen noch
Ersatzmodelle zeigen.

Wenn Roblox die API blockiert, funktionieren die nativen Reittiere weiter.
Prüfe als Ersteller bei Bedarf **Experience Settings → Security → Allow Mesh /
Image APIs**. Für veröffentlichte Spiele ist diese API standardmäßig deaktiviert.
Sitzhöhen, Speicherbudget und Rendering müssen lokal geprüft werden.

Die separaten `ExactCreatureModels/*.glb` enthalten dieselbe Originalgeometrie
als glTF-2.0-Dateien für den Studio-3D-Importer. Farben, Neon und Beleuchtung können
zwischen Browser, glTF-Importer und Roblox variieren. Sie sind keine bereits
hochgeladenen Roblox-Assets. Es wurden keine Assets gekauft oder veröffentlicht.
