# Roblox1

## Spawn-Design: LAUNCH YOUR MONSTER!

`assets/LaunchPlaza.rbxmx` enthält den gebauten Spawn im grünen Stud-/Kürbis-Stil:
Plaza, Monsterkanone, Mallow-Maskottchen, Eier- und Upgrade-Stände, Ranglisten-
Designs und eine Ringstrecke. Der Spawn erscheint beim Öffnen des Builds auch
ohne laufende Skripte. Shops und Kanone sind bisher Designobjekte.
Nach Generatoränderungen `python3 tools/build_spawn.py` ausführen und neu bauen.
Verifizierter Stand und offene Studio-Tests: [docs/BUILD_STATUS.md](docs/BUILD_STATUS.md).

Vorbereitet für Rojo 7.7.1. Benötigt lokal Python 3.9+ und Roblox Studio.
Die Cloud hat keinen direkten Zugriff auf dein lokal geöffnetes Studio.

## Auf deinem Rechner starten

1. Repository lokal herunterladen oder klonen und ein Terminal darin öffnen.
2. Studio installieren und einmal öffnen. Unter Windows ausführen:

   ```powershell
   py tools/rojo.py plugin install
   py tools/rojo.py serve
   ```

   Unter Mac/Linux `python3` statt `py` verwenden. Der Helfer lädt die passende
   offizielle Rojo-Version und prüft sie gegen die SHA-256-Prüfsummen der
   GitHub-Veröffentlichung. Linux unterstützt den CLI-Build, aber kein Studio.
3. Studio gegebenenfalls neu starten und zuerst einen leeren Test-Place öffnen.
   Im Rojo-Plugin mit `localhost`, Port `34872`, verbinden. Änderungen im Plugin
   prüfen. Vor der Synchronisierung eines bestehenden Spiels eine Kopie sichern.
4. Im Studio-Testmodus erscheinen eine Server- und eine Client-Meldung
   `Roblox1: ... bereit`. Strg+C beendet den Rojo-Server.

Rojo verwaltet ausschließlich die Unterordner `Roblox1` in ServerScriptService,
StarterPlayer/StarterPlayerScripts und ReplicatedStorage. Die Quelldateien liegen
in `src/server`, `src/client` und `src/shared`. Andere Service-Inhalte werden
beibehalten. Innerhalb der Roblox1-Ordner verwaltet Rojo alle Inhalte.

Build ohne Studio:

```powershell
py tools/rojo.py build -o build/Roblox1.rbxlx
```

## Claude Desktop

Eine direkte Verbindung zwischen dieser Cloud-Sitzung und Claude Desktop ist
nicht eingerichtet. Claude benötigt Zugriff auf dieselbe lokale Repository-Kopie.
Nutze eine in deiner Claude-Version verfügbare lokale Dateiintegration oder
übergib Dateien manuell. Ein Chat-Anhang gibt Claude keine lokalen Schreibrechte.
Du kannst Claude diese Anweisung geben:

> Arbeite im lokalen Repository Roblox1. Lies README.md und default.project.json.
> Bearbeite Luau-Dateien unter src/server, src/client und src/shared. Rojo
> synchronisiert diese Dateien mit Studio, während tools/rojo.py serve läuft.
> Prüfe Änderungen mit tools/rojo.py build -o build/Roblox1.rbxlx. Behaupte keine
> erfolgreichen Studio-Tests, wenn du Studio nicht bedienen kannst.

Git dient zum Austausch zwischen Cloud und Rechner: Änderungen lokal übernehmen
und dann Rojo laufen lassen. Rojo synchronisiert vom Dateisystem zu Studio;
bestehende Studio-Skripte werden nicht automatisch ins Repository exportiert.
Für diese lokale Synchronisierung sind keine API-Schlüssel nötig.
