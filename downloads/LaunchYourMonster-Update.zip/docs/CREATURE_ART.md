# Creature art provenance and import status

The user supplied three creature reference sheets, then the HTML showcase and its
original Three.js r160 JavaScript engine. The engine contains actual procedural
geometry for all 16 requested creatures. That source was executed in an isolated
Node VM without browser rendering, filesystem access or network capabilities in
the VM; its static mesh geometry was exported directly.

## Exact original geometry

`assets/exact_creatures.json` contains **78,019 source triangles** across all 16
creatures, batched into 2–4 material groups per creature. Geometry is not inferred
from screenshots. Source mesh transforms and triangle positions are retained;
coordinates are rotated 180 degrees around Y so forward is -Z, uniformly scaled
by 2.6, and normalized so the source model's lowest point is Y=0.

Material colors and vertex colors are converted from the source's linear color
space to clamped sRGB for Roblox. Native Roblox Neon approximates emissive source
materials, while each material batch retains its original opacity. Flat face
normals reproduce the source's faceted shading. Roblox lighting, bloom and tone
mapping differ from the browser renderer, so pixel-identical appearance is not
claimed. Pedestals, backgrounds and ambient particle systems in the reference
cards are not part of the creature meshes.

Original wing, jaw and tail animation callbacks are not baked into the static
mesh export. Existing Roblox flight cosmetics can move the whole model; exact
per-joint source animations are not implemented by this importer.

Re-extract with the user's original files:

```sh
node tools/extract_creatures.cjs path/to/three.js path/to/showcase-engine.js assets/exact_creatures.json
```

Schema:

- `version`: 1; `scale`: 2.6; `front`: `-Z`.
- `creatures[]`: `id`, `sourceId`, `name`, `bounds`, `seat`, `sourceMeshes`,
  `triangles`, `groups`.
- Each group: `neon`, `opacity`, flat vertex coordinate array `p`, flat RGB color
  palette `c`, zero-based color palette index per vertex `ci`, and flat zero-based
  triangle vertex indices `t`.
- `seat` is an authored/estimated saddle surface in normalized model coordinates.
  Character HumanoidRootPart sits at `modelPivot * CFrame.new(seat) *
  CFrame.new(0, 1.7, 0)`. Saddle clearance still needs a Studio visual test.

`game-overrides/ServerScriptService/Game/ExactCreatureLoader.luau` exposes:

```lua
local report = ExactCreatureLoader.Upgrade(assetModels, geometryFolder)
```

`geometryFolder` contains one StringValue per creature with that creature's JSON,
or one Folder per creature with lexically numbered StringValue chunks whose
concatenation is the creature JSON. Use chunks below 150 KB for large definitions.
The importer creates 2–4 native MeshParts per creature using EditableMesh,
`AddVertex`, `AddTriangle`, `AddColor`, `SetFaceColors`, `AddNormal` and
`SetFaceNormals`, then `CreateMeshPartAsync(Content.fromObject(...))`. It retains
live EditableMesh objects for the session and sets model Root/RideSeat metadata.
The import never purchases or publishes assets.

Call it in the background after fallback templates are ready. If the first
EditableMesh capability/memory error occurs, import stops once and the remaining
native templates stay usable. Status is reported through `ExactArtStatus`,
`ExactArtError` and `CreatureArtRevision` attributes on AssetModels. Dynamic mesh
API permissions, rendering, save behavior and server-to-client replication are
**not validated in this cloud session**. Studio and multiplayer tests remain
required. The importer does not claim that ephemeral Content objects are
permanently uploaded or published assets.

## Native-part fallback

`assets/CreatureMounts.rbxmx` contains a deterministic native-part interpretation
of the same reference silhouettes, built by `tools/build_creatures.py`. These are
lower-detail fallback models, **not exact copies of the original source meshes**.
They need no mesh API permission, imported meshes, texture IDs or asset purchase.

All 16 models have an invisible, anchored `Root` at the model origin, `Root` as
PrimaryPart, and a `RideSeat` Attachment. Front is -Z. Every part is anchored,
non-colliding, non-touching and non-queryable; no real physics Seat is included.

| Existing game ID | Display creature | Native parts | Source triangles |
| --- | --- | ---: | ---: |
| Mallow | Mallow | 92 | 5,767 |
| PuddlePup | Puddle Pup | 65 | 4,742 |
| AeroKitty | Aero Kitty | 83 | 3,153 |
| LeafGecko | Leaf Gecko | 50 | 1,236 |
| EmberChick | Ember Chick | 74 | 6,926 |
| StarBunny | Star Bunny | 50 | 3,608 |
| StormFox | Storm Fox | 75 | 6,140 |
| CloudSerpent | Cloud Serpent | 60 | 4,894 |
| CrystalOtter | Crystal Otter | 75 | 3,675 |
| RocketRaccoon | Rocket Ringtail | 71 | 2,968 |
| AuroraLynx | Aurora Lynx | 77 | 10,307 |
| NeonWyvern | Neon Wyvern | 96 | 5,500 |
| SolarManta | Solar Manta | 52 | 2,554 |
| ThunderHydra | Thunder Hydra | 118 | 9,207 |
| QuantumPhoenix | Quantum Phoenix | 68 | 4,604 |
| CosmicLeviathan | Cosmic Leviathan | 48 | 2,738 |
| **Total** | **16 models** | **1,154** | **78,019** |

The existing `RocketRaccoon` ID is retained to preserve saved inventories;
`Rocket Ringtail` is the reference's display name.

## Validation performed

- Generated all 16 native fallback models and checked Root/RideSeat, PrimaryPart
  references, anchored flags and disabled collision/query/touch properties.
- Executed all 16 original Three.js builders and exported their mesh triangles.
- Verified every triangle index and color palette index is within array bounds,
  and every vertex has a color assignment.
- No Studio render, mount animation, EditableMesh permission or multiplayer
  replication test was available in this cloud environment.

## Current game integration

The upgraded place includes this loader in both server and shared Game modules.
RidingClient invokes it locally after AssetModels is available, using the replicated
ExactCreatureGeometry data. Server-owned riding uses the native templates; each
client independently overlays original meshes and seats its displayed avatar when
conversion succeeds. This avoids assuming EditableMesh Content replication.
ExactCreatureModels/*.glb is an additional portable glTF export of source triangles.
