"""Integrate reviewed source overrides and native art into a COPY of a supplied place.
Usage: python3 tools/upgrade_place.py input.rbxlx [output.rbxlx]
Keeps original services, scripts, AI generations and SharedStrings intact.
"""
from pathlib import Path
import copy
import math
import re
import sys
import xml.etree.ElementTree as E
ROOT=Path(__file__).resolve().parents[1]
seq=0

def name(i):return i.findtext("Properties/string[@name='Name']",i.get('class'))
def find(parent,n):return next((i for i in parent.findall('Item') if name(i)==n),None)
def props(i):
 p=i.find('Properties')
 if p is None:p=E.SubElement(i,'Properties')
 return p

def setp(i,typ,n,value):
 p=props(i)
 for old in list(p):
  if old.get('name')==n:p.remove(old)
 e=E.SubElement(p,typ,name=n);e.text=str(value).lower() if isinstance(value,bool) else str(value)
 return e

def vector(i,typ,n,values,keys):
 e=setp(i,typ,n,'');e.text=None
 for k,v in zip(keys,values):E.SubElement(e,k).text=str(v)
 return e

def item(parent,cls,n):
 i=E.SubElement(parent,'Item',{'class':cls});setp(i,'string','Name',n);return i

def fresh(i):
 global seq
 mapping={}
 for c in i.iter('Item'):
  seq+=1;old=c.get('referent');new='LYMNEW'+str(seq)
  if old:mapping[old]=new
  c.set('referent',new)
 for ref in i.iter('Ref'):
  if ref.text in mapping:ref.text=mapping[ref.text]
 return i

def write(root,path):
 path.parent.mkdir(parents=True,exist_ok=True)
 E.indent(root);E.ElementTree(root).write(path,encoding='utf-8',xml_declaration=False)

def build(input_path,output_path):
 global seq
 root=E.parse(input_path).getroot()
 seq=max([int(i.get('referent')[6:]) for i in root.iter('Item') if re.fullmatch(r'LYMNEW[0-9]+',i.get('referent',''))] or [0])
 services={i.get('class'):i for i in root.findall('Item')}
 modified=[]
 def walk(i,path=''):
  path=(path+'/'+name(i)).strip('/')
  override=ROOT/'game-overrides'/(path+'.luau')
  if i.get('class') in ('Script','LocalScript','ModuleScript') and override.is_file():
   setp(i,'ProtectedString','Source',override.read_text());modified.append(path)
  for child in i.findall('Item'):walk(child,path)
 for service in root.findall('Item'):walk(service)
 game=find(services['ServerScriptService'],'Game')
 for module in ['HubDesign','PlazaBoards','DailyMissionRules','Riding','ExactCreatureLoader']:
  i=find(game,module)
  if i is None:i=item(game,'ModuleScript',module)
  setp(i,'ProtectedString','Source',(ROOT/'game-overrides/ServerScriptService/Game'/f'{module}.luau').read_text());fresh(i)
 client=find(find(services['StarterPlayer'],'StarterPlayerScripts'),'Client')
 riding=find(client,'RidingClient')
 if riding is None:riding=item(client,'ModuleScript','RidingClient')
 setp(riding,'ProtectedString','Source',(ROOT/'game-overrides/StarterPlayer/StarterPlayerScripts/Client/RidingClient.luau').read_text());fresh(riding)
 # Build saved assets from the source's own mesh parts, using its original manifest.
 rs=services['ReplicatedStorage'];storage=services['ServerStorage']
 old=find(rs,'AssetModels')
 if old is not None:rs.remove(old)
 templates=item(rs,'Folder','AssetModels')
 mesh_by_id={i.findtext("Properties/Content[@name='MeshId']/url"):i for i in root.iter('Item') if i.get('class')=='MeshPart'}
 manifest=find(find(rs,'Assets'),'Manifest').findtext("Properties/ProtectedString[@name='Source']")
 category=None;asset_count=0
 for line in manifest.splitlines():
  m=re.match(r'\t(\w+) = \{',line)
  if m:category=item(templates,'Folder',m.group(1));continue
  m=re.match(r'\t\t(\w+) = \{ parts =',line)
  if not m:continue
  model=item(category,'Model',m.group(1));largest=None;largest_volume=0
  pattern=r'name = "([^"]+)", mesh = "([^"]+)", texture = "([^"]+)", size = \{ ([^}]+) \}, cf = \{ ([^}]+) \}'
  bottoms=[]
  for partname,mesh,texture,size,cf in re.findall(pattern,line):
   assert mesh in mesh_by_id, f'Missing saved mesh {mesh}'
   part=copy.deepcopy(mesh_by_id[mesh]);fresh(part)
   # No embedded scripts or joint references in art templates.
   for child in list(part.findall('Item')):part.remove(child)
   setp(part,'string','Name',partname)
   for k,val in [('Anchored',True),('CanCollide',False),('CanTouch',False),('CanQuery',False)]:setp(part,'bool',k,val)
   values=[float(v) for v in size.split(',')];coordinates=[float(v) for v in cf.split(',')]
   vector(part,'Vector3','size',values,'XYZ')
   vector(part,'CoordinateFrame','CFrame',coordinates,('X','Y','Z','R00','R01','R02','R10','R11','R12','R20','R21','R22'))
   model.append(part);bottoms.append(coordinates[1]-values[1]/2)
   volume=math.prod(values)
   if volume>largest_volume:largest_volume=volume;largest=part
  assert largest is not None,name(model)
  setp(model,'Ref','PrimaryPart',largest.get('referent'))
  # Put all templates on a stable bottom-center origin, then use primary part pivot.
  bottom=min(bottoms)
  for part in model.findall('Item'):
   c=props(part).find("CoordinateFrame[@name='CFrame']");c.find('Y').text=str(float(c.findtext('Y'))-bottom)
  # PrimaryPart pivot is explicitly set by AssetLoader before placing/cloning.
  setp(model,'bool','NeedsPivotMigration',False)
  asset_count+=1
 # Original AI meshes stay in AIGenerations; use optimized reference-style mount art.
 native=copy.deepcopy(E.parse(ROOT/'assets/CreatureMounts.rbxmx').getroot().find('Item'))
 setp(native,'string','Name','Monsters')
 old_monsters=find(templates,'Monsters')
 if old_monsters is not None:templates.remove(old_monsters)
 templates.append(native)
 fresh(templates)
 # Original geometry is available to the client-local mesh importer as well as Edit tools.
 for service in [storage,rs]:
  old_geometry=find(service,'ExactCreatureGeometry')
  if old_geometry is not None:service.remove(old_geometry)
  geometry=item(service,'Folder','ExactCreatureGeometry')
  for creature in __import__('json').loads((ROOT/'assets/exact_creatures.json').read_text())['creatures']:
   encoded=__import__('json').dumps(creature,separators=(',',':'))
   if len(encoded)<=130000:
    value=item(geometry,'StringValue',creature['id']);setp(value,'string','Value',encoded)
   else:
    chunks=item(geometry,'Folder',creature['id'])
    for offset in range(0,len(encoded),130000):
     value=item(chunks,'StringValue',str(offset//130000).zfill(4));setp(value,'string','Value',encoded[offset:offset+130000])
 shared_game=find(rs,'Game')
 exact=find(shared_game,'ExactCreatureLoader')
 if exact is None:exact=item(shared_game,'ModuleScript','ExactCreatureLoader')
 setp(exact,'ProtectedString','Source',(ROOT/'game-overrides/ServerScriptService/Game/ExactCreatureLoader.luau').read_text());fresh(exact)
 # Native stud plaza template, arranged around the existing hub/cannon coordinates.
 plaza=copy.deepcopy(E.parse(ROOT/'assets/LaunchPlaza.rbxmx').getroot().find('Item'))
 setp(plaza,'string','Name','LYM_StudPlaza')
 launcher=item(plaza,'Model','Launcher');assembly=item(launcher,'Model','BarrelAssembly')
 removed={'FlightLane','FlightRing','MeadowEgg','Spawn'}
 cannon_names={'LaunchDeck','CannonWheel','CannonMount'}
 panels=[]
 # Associate standalone sign frames/panels by authored position.
 for p in list(plaza.findall('Item')):
  n=name(p)
  if n in removed:plaza.remove(p);continue
  coord=props(p).find("CoordinateFrame[@name='CFrame']")
  if coord is not None:
   coord.find('Z').text=str(float(coord.findtext('Z'))-42)
  if n in cannon_names:
   plaza.remove(p);launcher.append(p)
  if n in ['BlueBarrel','GoldenMuzzle','DarkMuzzle']:
   plaza.remove(p);assembly.append(p)
   xyz={'BlueBarrel':(0,8.7,-5.3),'GoldenMuzzle':(0,13.3,-.7),'DarkMuzzle':(0,14,0)}[n]
   a=math.radians(45);s=math.sin(a);c=math.cos(a)
   vector(p,'CoordinateFrame','CFrame',(*xyz,0,-1,0,s,0,-c,c,0,s),('X','Y','Z','R00','R01','R02','R10','R11','R12','R20','R21','R22'))
   if n=='BlueBarrel':setp(p,'string','Name','barrel')
  if n in ['SignPanel','SignFrame'] and coord is not None:
   x=float(coord.findtext('X'));y=float(coord.findtext('Y'))
   if y==12 and abs(x)==29:
    coord.find('Z').text=str(float(coord.findtext('Z'))+48)
   if n=='SignPanel':panels.append(p)
  if n=='Pumpkin':
   light=item(p,'PointLight','PumpkinGlow');setp(light,'float','Brightness',.7);setp(light,'float','Range',10)
 for p in panels:
  t=p.find("Item/Item/Properties/string[@name='Text']")
  if t is None:continue
  coord=props(p).find("CoordinateFrame[@name='CFrame']")
  if float(coord.findtext('Z')) > -58:setp(p.find('Item'),'token','Face',5)
  old=t.text or ''
  t.text=old.replace('Hatching coming soon','250 STAR COINS').replace('Workshop coming soon','MORE POWER • MORE DISTANCE').replace('Cannon design preview','TIME YOUR PERFECT SHOT')
  if 'BEST DISTANCE' in old or 'STAR COINS' in old:
   setp(p,'string','Name','DistanceBoard' if 'BEST' in old else 'CoinsBoard')
   t.text=('BEST DISTANCE' if 'BEST' in old else 'STAR COINS')+'\nTHIS SERVER\nWaiting for players...'
   # Surface text must remain readable when eight entries are present.
   setp(p.find('Item').find('Item'),'bool','TextScaled',True)
 # Clone a third live board near the back wall rather than obstructing the flight lane.
 third=copy.deepcopy(next(p for p in panels if name(p)=='DistanceBoard'));setp(third,'string','Name','LaunchesBoard')
 c=props(third).find("CoordinateFrame[@name='CFrame']");c.find('X').text='0';c.find('Y').text='12';c.find('Z').text='-90'
 third.find("Item/Item/Properties/string[@name='Text']").text='TOTAL LAUNCHES\nTHIS SERVER\nWaiting for players...';plaza.append(third)
 holder=item(launcher,'Part','PromptHolder')
 vector(holder,'Vector3','size',(2,2,2),'XYZ');vector(holder,'CoordinateFrame','CFrame',(0,4,-22,1,0,0,0,1,0,0,0,1),('X','Y','Z','R00','R01','R02','R10','R11','R12','R20','R21','R22'))
 for k,val in [('Anchored',True),('CanCollide',False),('CanTouch',False),('CanQuery',False)]:setp(holder,'bool',k,val)
 setp(holder,'float','Transparency',1)
 # Decorative labels, vegetation, lamps and barrel surfaces never trap characters.
 for p in plaza.iter('Item'):
  n=name(p)
  if p.get('class')=='Part' and (n.startswith('Mallow') or n.startswith('Glowing') or p in panels or n in ['barrel','GoldenMuzzle','DarkMuzzle']):setp(p,'bool','CanCollide',False)
 fresh(plaza)
 old=find(storage,'LYM_StudPlaza')
 if old is not None:storage.remove(old)
 storage.append(plaza)
 preview=copy.deepcopy(plaza);setp(preview,'string','Name','LYM_DesignPreview');fresh(preview)
 ws=services['Workspace'];old=find(ws,'LYM_DesignPreview')
 if old is not None:ws.remove(old)
 ws.append(preview)
 # Ready-to-inspect editing camera. Runtime character cameras remain controlled by Client.
 camera=find(ws,'Camera')
 if camera is not None:
  def sub(a,b):return [x-y for x,y in zip(a,b)]
  def unit(a):
   length=math.sqrt(sum(x*x for x in a));return [x/length for x in a]
  def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
  position=[105.,85.,-165.];target=[0.,8.,-48.]
  back=unit(sub(position,target));right=unit(cross([0,1,0],back));up=cross(back,right)
  matrix=[v for row in zip(right,up,back) for v in row]
  vector(camera,'CoordinateFrame','CFrame',(*position,*matrix),('X','Y','Z','R00','R01','R02','R10','R11','R12','R20','R21','R22'))
 # Assign stable unique referents to newly authored modules/folders without changing originals.
 for i in root.iter('Item'):
  if not i.get('referent'):
   seq+=1;i.set('referent','LYMNEW'+str(seq))
 write(root,output_path)
 print(f'Updated {len(modified)+7} scripts; embedded {asset_count} asset templates; integrated plaza + edit preview -> {output_path}')

if __name__=='__main__':
 if len(sys.argv)<2:raise SystemExit('Usage: python3 tools/upgrade_place.py input.rbxlx [output.rbxlx]')
 build(Path(sys.argv[1]),Path(sys.argv[2]) if len(sys.argv)>2 else ROOT/'build/LaunchYourMonster-Updated.rbxlx')
