"""Build an original, static Roblox spawn model without external assets."""
from pathlib import Path
import math
import xml.etree.ElementTree as X
ROOT = Path(__file__).resolve().parents[1]
xml=X.Element('roblox',version='4')
model=X.SubElement(xml,'Item',{'class':'Model','referent':'Plaza'})
props=X.SubElement(model,'Properties'); X.SubElement(props,'string',name='Name').text='LaunchPlaza'
GREEN=(97,210,24); LIME=(161,242,44); BROWN=(111,53,26); ORANGE=(255,143,20); BLUE=(49,164,255); DARK=(25,29,40); WHITE=(255,249,222)
count=0

def prop(p,typ,name,value):
 e=X.SubElement(p,typ,name=name); e.text=str(value).lower() if isinstance(value,bool) else str(value); return e

def vec(p,typ,name,values,keys):
 e=X.SubElement(p,typ,name=name)
 for k,v in zip(keys,values): X.SubElement(e,k).text=str(v)
 return e

def part(name,pos,size,color,parent=model,kind='Part',shape=None,rotation=0,neon=False,collide=True):
 global count
 count+=1
 item=X.SubElement(parent,'Item',{'class':kind,'referent':f'P{count}'})
 p=X.SubElement(item,'Properties')
 prop(p,'string','Name',name); prop(p,'bool','Anchored',True); prop(p,'bool','CanCollide',collide)
 vec(p,'Vector3','size',size,'XYZ'); vec(p,'Color3','Color',[v/255 for v in color],'RGB')
 a=math.radians(rotation); c=math.cos(a); s=math.sin(a)
 vec(p,'CoordinateFrame','CFrame',(*pos,c,0,s,0,1,0,-s,0,c),('X','Y','Z','R00','R01','R02','R10','R11','R12','R20','R21','R22'))
 prop(p,'token','TopSurface',3 if not neon else 0); prop(p,'token','BottomSurface',0)
 if neon: prop(p,'token','Material',288)
 if shape is not None: prop(p,'token','shape',shape)
 return item,p

def label(parent,text,color=WHITE):
 gui=X.SubElement(parent,'Item',{'class':'SurfaceGui'})
 p=X.SubElement(gui,'Properties');prop(p,'string','Name','Sign');prop(p,'token','Face',2)
 vec(p,'Vector2','CanvasSize',(600,400),('X','Y'));prop(p,'float','LightInfluence',0)
 t=X.SubElement(gui,'Item',{'class':'TextLabel'});p=X.SubElement(t,'Properties')
 prop(p,'string','Name','Caption');prop(p,'string','Text',text);prop(p,'float','BackgroundTransparency',1)
 prop(p,'bool','TextScaled',True);prop(p,'bool','TextWrapped',True);prop(p,'token','Font',20)
 prop(p,'float','TextStrokeTransparency',0)
 vec(p,'Color3','TextColor3',[v/255 for v in color],'RGB')
 e=X.SubElement(p,'UDim2',name='Size')
 for k,v in [('XS',.92),('XO',0),('YS',.9),('YO',0)]:X.SubElement(e,k).text=str(v)
 e=X.SubElement(p,'UDim2',name='Position')
 for k,v in [('XS',.04),('XO',0),('YS',.05),('YO',0)]:X.SubElement(e,k).text=str(v)

def sign(text,x,z,width=18,color=LIME,y=12):
 part('SignFrame',(x,y,z),(width+1,10,1.2),ORANGE)
 panel,_=part('SignPanel',(x,y,z+.7),(width,9,.3),DARK)
 label(panel,text,color)

def pumpkin(x,z,scale=1):
 part('Pumpkin',(x,2+scale*2,z),(scale*4,scale*4,scale*4),ORANGE)
 for dx in [-.9,.9]: part('GlowingEye',(x+dx*scale,2+2.5*scale,z+2.03*scale),(.65*scale,.85*scale,.1),(255,224,75),neon=True,collide=False)
 part('GlowingGrin',(x,2+1.2*scale,z+2.03*scale),(1.9*scale,.45*scale,.1),(255,224,75),neon=True,collide=False)
 part('Stem',(x,2+4.3*scale,z),(.65*scale,scale,.65*scale),GREEN,rotation=20)

def tree(x,z,h=14):
 part('Trunk',(x,2+h/2,z),(2.8,h,2.8),BROWN)
 part('Crown',(x,2+h,z),(12,9,12),GREEN)
 part('CrownTop',(x-2,7+h,z),(8,4,8),LIME)

# A compact square, with an open northern launch lane (+Z).
for x in range(-44,45,8):
 for z in range(-44,45,8):
  path=abs(x)<8 or abs(z)<8
  part('PathTile' if path else 'GrassTile',(x,0,z),(8,2,8),ORANGE if path else (GREEN if (x+z)//8%2 else LIME))
for x in [-50,50]:
 for z in range(-44,45,8):
  part('Cliff',(x,8,z),(6,18,8),BROWN)
  part('GrassLip',(x,18,z),(7,2,8),GREEN)
for x in range(-44,45,8):
 part('BackCliff',(x,8,-50),(8,18,6),BROWN)
 part('BackGrass',(x,18,-50),(8,2,7),GREEN)
for x,z in [(-38,-28),(38,-28),(-39,27),(39,27),(-24,39),(24,39)]: tree(x,z)
for x,z,s in [(-44,-40,1.4),(-36,-40,.8),(42,-40,1.2),(35,18,.8),(-34,18,1),(43,38,.7)]:pumpkin(x,z,s)
spawn,p=part('Spawn',(0,1.5,-25),(10,1,10),(81,216,255),kind='SpawnLocation')
prop(p,'bool','Neutral',True);prop(p,'bool','Enabled',True);prop(p,'float','Duration',0)
sign('LAUNCH YOUR\nMONSTER!',0,-46,29,WHITE,24)
sign('BEST DISTANCE\nLive rankings coming soon',-29,-43,18,BLUE)
sign('STAR COINS\nLive rankings coming soon',29,-43,18,LIME)
# Stalls sit on either side of the circulation path; face the arrival area.
for x,title,color in [(-28,'MEADOW EGG\nHatching coming soon',LIME),(28,'UPGRADES\nWorkshop coming soon',BLUE)]:
 part('KioskCounter',(x,3,-8),(14,4,8),BROWN)
 for dx in [-7,7]:part('KioskPost',(x+dx,7,-10),(1,12,1),ORANGE)
 for dx in range(-6,7,2):part('Awning',(x+dx,13,-8),(2,1,10),color if dx%4 else WHITE)
 sign(title,x,-12,15,color,18)
 if x<0:part('MeadowEgg',(x,7,-7),(4,5,4),LIME,shape=0)
 else:
  for dx in [-3,3]: part('UpgradeCrystal',(x+dx,7,-7),(2,4,2),BLUE,neon=True,collide=False)
# Large cartoon cannon: native cylinder primitive has its axis along local X.
part('LaunchDeck',(0,2,30),(24,2,24),BROWN)
for x in [-7,7]:part('CannonWheel',(x,5,28),(3,8,8),DARK,shape=2)
part('CannonMount',(0,5,28),(10,5,8),ORANGE)
# Build tilted rings from a hand-authored orthonormal frame.
def barrel(name,z,y,length,radius,color):
 item,p=part(name,(0,y,z),(length,radius,radius),color,shape=2)
 e=p.find("CoordinateFrame[@name='CFrame']")
 # Local X points up/forward at 25 degrees; local Y points horizontally left.
 a=math.radians(25);sn=math.sin(a);cs=math.cos(a)
 for k,v in {'R00':0,'R01':-1,'R02':0,'R10':sn,'R11':0,'R12':-cs,'R20':cs,'R21':0,'R22':sn}.items():e.find(k).text=str(v)
barrel('BlueBarrel',30,9,14,8,BLUE)
barrel('GoldenMuzzle',36.35,11.96,2,9,ORANGE)
barrel('DarkMuzzle',37.3,12.4,.15,7,DARK)
sign('LAUNCH!\nCannon design preview',0,21,20,LIME,20)
# Exit arch, clear flight direction and small illustrative route beyond the plaza.
for x in [-15,15]:part('LaunchArchPost',(x,14,44),(3,28,3),ORANGE)
part('LaunchArchTop',(0,28,44),(33,3,3),ORANGE)
for z in range(52,149,8):
 part('FlightLane',(0,-1,z),(28,2,8),GREEN if z%16 else LIME)
for z in [65,95,125]:
 for i in range(12):
  a=i*math.tau/12
  part('FlightRing',(math.cos(a)*7,14+math.sin(a)*7,z),(2.5,2.5,1),(255,221,70),neon=True,collide=False)
# Mallow-inspired original mascot: rounded blue body, tiny wings, friendly eyes.
part('MallowBody',(-18,5,-27),(5,5,4),BLUE,shape=0,collide=False)
part('MallowBelly',(-18,4.5,-24.9),(2.8,2.8,.4),WHITE,shape=0,collide=False)
for x in [-19,-17]:
 part('MallowEye',(x,6,-25.1),(.65,.9,.3),DARK,shape=0,collide=False)
 part('MallowHorn',(x,8,-27),(.65,1,.65),WHITE)
for x in [-21, -15]:part('MallowWing',(x,5.5,-27),(2,1,2.5),WHITE,collide=False)
sign('WELCOME!\nMeet Mallow',-20,-32,13,BLUE,11)
(ROOT/'assets').mkdir(exist_ok=True)
X.indent(xml)
X.ElementTree(xml).write(ROOT/'assets/LaunchPlaza.rbxmx',encoding='utf-8',xml_declaration=True)
print(f'Generated LaunchPlaza: {count} anchored parts')
