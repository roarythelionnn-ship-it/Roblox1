"""Build 16 original native-part mounts from the supplied creature reference sheets.

No images are converted to meshes and no external assets are downloaded. The result
is a deterministic, editable faceted interpretation of the reference silhouettes.
Front is -Z, ground is Y=0, Root is the model pivot. RideSeat is an Attachment,
not a physics Seat. Run: python3 tools/build_creatures.py
"""
from pathlib import Path
import math
import xml.etree.ElementTree as E

ROOT = Path(__file__).resolve().parents[1]
WHITE='F3F5FF'; BLACK='13152A'; GOLD='F7CE60'
COUNTS = {}
SEQ = 0
IDENTITY = (1,0,0,0,1,0,0,0,1)


def prop(item, kind, name, value):
    p = item.find('Properties')
    if p is None:
        p = E.SubElement(item, 'Properties')
    e = E.SubElement(p, kind, name=name)
    if value is not None:
        e.text = str(value).lower() if isinstance(value, bool) else str(value)
    return e


def vector(item, kind, name, values, keys):
    e=prop(item,kind,name,None)
    for k,v in zip(keys,values):
        E.SubElement(e,k).text=f'{v:.6f}' if isinstance(v,float) else str(v)
    return e


def matrix(rotation):
    x,y,z=(math.radians(v) for v in rotation)
    cx,sx,cy,sy,cz,sz=math.cos(x),math.sin(x),math.cos(y),math.sin(y),math.cos(z),math.sin(z)
    return (cy*cz, sx*sy*cz-cx*sz, cx*sy*cz+sx*sz,
            cy*sz, sx*sy*sz+cx*cz, cx*sy*sz-sx*cz,
            -sy, sx*cy, cx*cy)


def color(hexcode):
    return tuple(int(hexcode[i:i+2],16)/255 for i in (0,2,4))


def make(parent, cls, name):
    global SEQ
    SEQ+=1
    i=E.SubElement(parent,'Item',{'class':cls,'referent':f'CREATURE_{SEQ}'})
    prop(i,'string','Name',name)
    return i


class Creature:
    def __init__(self, parent, key, body, accent, glow):
        self.key=key;self.body=body;self.accent=accent;self.glow=glow;self.count=0
        self.model=make(parent,'Model',key)
        self.root=self.part('Root',(0,0,0),(.2,.2,.2),body,transparent=1)
        prop(self.model,'Ref','PrimaryPart',self.root.get('referent'))
        self.saddle_y=3.6

    def part(self, name, pos, size, tint, rotation=(0,0,0), wedge=False, neon=False, transparent=0):
        p=make(self.model,'WedgePart' if wedge else 'Part',name)
        self.count+=1
        for k,v in [('Anchored',True),('CanCollide',False),('CanTouch',False),('CanQuery',False),('CastShadow',not neon)]:
            prop(p,'bool',k,v)
        prop(p,'token','TopSurface',0);prop(p,'token','BottomSurface',0)
        prop(p,'token','Material',288 if neon else 256)
        prop(p,'float','Transparency',transparent)
        vector(p,'Vector3','size',size,'XYZ')
        vector(p,'Color3','Color',color(tint),'RGB')
        vector(p,'CoordinateFrame','CFrame',(*pos,*matrix(rotation)),('X','Y','Z','R00','R01','R02','R10','R11','R12','R20','R21','R22'))
        return p

    def rod(self,name,start,end,width,tint,neon=False):
        # Thin square beam with local Y along the endpoint segment.
        delta=[b-a for a,b in zip(start,end)];length=math.sqrt(sum(v*v for v in delta))
        if length < .001:return
        y=[v/length for v in delta]
        basis=(0,0,1) if abs(y[2])<.9 else (1,0,0)
        x=[basis[1]*y[2]-basis[2]*y[1],basis[2]*y[0]-basis[0]*y[2],basis[0]*y[1]-basis[1]*y[0]]
        mag=math.sqrt(sum(v*v for v in x));x=[v/mag for v in x]
        z=[x[1]*y[2]-x[2]*y[1],x[2]*y[0]-x[0]*y[2],x[0]*y[1]-x[1]*y[0]]
        p=self.part(name,tuple((a+b)/2 for a,b in zip(start,end)),(width,length,width),tint,neon=neon)
        cf=p.find("Properties/CoordinateFrame[@name='CFrame']")
        for k,v in zip(('R00','R01','R02','R10','R11','R12','R20','R21','R22'),[v for row in zip(x,y,z) for v in row]):
            cf.find(k).text=f'{v:.6f}'
        return p

    def facet_body(self,pos,size,tint=None):
        tint=tint or self.body;x,y,z=pos;w,h,d=size
        self.part('BodyCore',pos,(w*.78,h*.78,d*.82),tint)
        shades=[tint,self.accent,tint,self.body]
        for side in (-1,1):
            self.part('ShoulderFacet',(x+side*w*.36,y+h*.2,z-d*.18),(w*.28,h*.55,d*.55),shades[side+1],rotation=(0,0,side*16),wedge=True)
            self.part('FlankFacet',(x+side*w*.4,y-h*.08,z+d*.1),(w*.23,h*.65,d*.63),tint,rotation=(0,side*180,0),wedge=True)
        self.part('ChestFacet',(x,y-h*.05,z-d*.43),(w*.74,h*.7,d*.28),self.accent,wedge=True,rotation=(0,180,0))
        self.part('RumpFacet',(x,y,z+d*.4),(w*.7,h*.65,d*.3),tint,wedge=True)
        self.part('BackFacet',(x,y+h*.4,z),(w*.62,h*.23,d*.7),tint,rotation=(0,0,180),wedge=True)

    def legs(self,width=1.12,front=-1.65,rear=1.65,paws=WHITE):
        for x in (-width,width):
            for z in (front,rear):
                self.part('Haunch',(x,1.7,z),(.85,1.6,1),self.body,rotation=(8 if z>0 else -8,0,0))
                self.part('LowerLeg',(x, .75,z-.1),(.57,1.3,.65),self.accent)
                self.part('Paw',(x,.27,z-.38),(.9,.48,1.15),self.body)
                for dx in (-.22,0,.22):
                    self.part('Claw',(x+dx,.28,z-.95),(.13,.23,.38),paws,wedge=True,rotation=(0,180,0))

    def head(self,pos=(0,4,-2.5),size=(2.6,2.1,2.6),ears=True,muzzle=True):
        self.facet_body(pos,size)
        x,y,z=pos;w,h,d=size
        if muzzle:
            self.part('Muzzle',(x,y-h*.2,z-d*.55),(w*.75,h*.45,d*.65),self.accent,wedge=True,rotation=(0,180,0))
            self.part('Nose',(x,y-h*.13,z-d*.87),(w*.35,h*.2,.3),BLACK)
        for side in (-1,1):
            self.part('EyeSocket',(x+side*w*.38,y+h*.12,z-d*.39),(.5,.58,.5),BLACK,rotation=(0,side*-18,0))
            self.part('LuminousEye',(x+side*w*.4,y+h*.15,z-d*.49),(.31,.3,.15),self.glow,neon=True)
            self.part('EyeGlint',(x+side*w*.4-.06,y+h*.2,z-d*.58),(.08,.09,.04),WHITE,neon=True)
            if ears:
                self.part('Ear',(x+side*w*.35,y+h*.7,z+.1),(.75,1.5,.55),self.body,rotation=(0,side*12,side*-20),wedge=True)
                self.part('InnerEar',(x+side*w*.35,y+h*.7,z-.22),(.38,.85,.1),self.accent,rotation=(0,0,side*-20),wedge=True)

    def horn(self,start,end,tint=GOLD):
        mid=tuple(a+(b-a)*.55 for a,b in zip(start,end))
        self.rod('HornBase',start,mid,.3,tint)
        self.rod('HornTip',mid,end,.12,tint)

    def tail(self,points,tint=None,width=.65,tip=None):
        tint=tint or self.body
        for n,(a,b) in enumerate(zip(points,points[1:])):
            self.rod('TailSegment',a,b,width*(1-n/(len(points)+.5)),tint)
        if tip:
            x,y,z=points[-1];self.part('TailGem',(x,y,z),(.65,.9,.65),tip,rotation=(0,0,35),wedge=True,neon=True)

    def wings(self,feather=False,span=6,rise=3,tint=None):
        tint=tint or self.accent
        for side in (-1,1):
            a=(side*1.2,3.5,-.8);b=(side*span,3.5+rise,.6);c=(side*span*.77,3.5+rise*.14,2.6)
            self.rod('WingLeadingEdge',a,b,.2,self.body)
            self.rod('WingTrailingEdge',a,c,.13,self.body)
            if feather:
                for n in range(9):
                    t=n/9; x=side*(1.6+(span-1.4)*t)
                    yy=3.5+rise*t
                    self.part('BladeFeather',(x,yy,1.1+t*.45),(.38,1.6,2.7-t*.75),tint if n%2 else self.glow,rotation=(-25,side*(18+n*3),side*-40),wedge=True,neon=n>6)
            else:
                for n in range(3):
                    t=(n+.5)/3
                    self.part('WingMembrane',(side*(1.7+(span-1.7)*t),3.8+rise*t*.8,1.05),((span-1.3)/3+.25,1.65,2.3),tint,rotation=(0,side*-8,side*-28),wedge=True)
                    self.rod('WingRib',a,(side*(2.3+(span-2)*t),4+rise*t,2.3),.1,self.body)

    def crystals(self,count=7,along=3,tint=None,y=4):
        tint=tint or self.glow
        for n in range(count):
            z=-along/2+along*n/max(1,count-1)
            side=-1 if n%2 else 1
            self.part('DorsalCrystal',(side*.45,y+.2+(n%3)*.15,z),(.65,1.4+(n%3)*.4,.7),tint,rotation=(0,side*22,side*-16),wedge=True,neon=n%3==0)

    def finish(self,seat=(0,3.6,.1)):
        # A visible low saddle avoids a floating avatar and keeps the animal silhouette.
        self.part('SaddlePad',(seat[0],seat[1]-.15,seat[2]),(1.7,.25,1.8),BLACK)
        self.part('SaddleTrim',(seat[0],seat[1]-.32,seat[2]),(1.85,.13,1.9),self.accent)
        for side in (-1,1):
            self.part('SaddleStrap',(seat[0]+side*.94,seat[1]-.55,seat[2]),(.12,.9,.35),GOLD)
        att=make(self.root,'Attachment','RideSeat')
        vector(att,'CoordinateFrame','CFrame',(*seat,*IDENTITY),('X','Y','Z','R00','R01','R02','R10','R11','R12','R20','R21','R22'))
        COUNTS[self.key]=self.count


def quadruped(parent,key,body,accent,glow):
    c=Creature(parent,key,body,accent,glow)
    c.facet_body((0,2.55,.1),(3.2,2.2,4.7));c.legs(paws=accent);c.head()
    return c


def dragon(parent,key,body,accent,glow,neon=False):
    c=quadruped(parent,key,body,accent,glow)
    c.wings(span=6.5 if neon else 5.7,rise=4.4 if neon else 3.3,tint=accent)
    for side in (-1,1):
        c.horn((side*.85,4.9,-2.2),(side*1.2,6.2,-1.6),accent)
        for n in range(3):c.part('Fang',(side*(.5+n*.22),3.4,-3.7),(.13,.4,.16),WHITE,wedge=True)
    c.tail([(0,2.6,2.3),(0,2.4,4.1),(.9,3,5.7),(1.7,3.7,6.8)],tip=glow)
    c.crystals(5,2.8,glow,y=3.6)
    return c


def bird(parent,key,body,accent,glow):
    c=Creature(parent,key,body,accent,glow)
    c.facet_body((0,2.7,0),(2.9,3.4,3.2));c.head((0,4.8,-1.5),(1.8,1.7,1.9),ears=False,muzzle=False)
    c.part('Beak',(0,4.6,-2.7),(.7,.7,1.3),GOLD,wedge=True,rotation=(0,180,0))
    for side in (-1,1):
        c.rod('BirdLeg',(side*.65,1.4,.25),(side*.65,.3,-.15),.22,GOLD)
        for dx in (-.25,0,.25):c.rod('BirdToe',(side*.65,.25,-.15),(side*.65+dx,.18,-1),.12,GOLD)
    c.wings(feather=True,span=7.2,rise=4.4)
    for n in range(5):
        c.part('Crest',(0,6.1+n*.2,-1.2+n*.12),(.28,1.4+n*.25,.38),glow,rotation=(-12,0,0),wedge=True,neon=True)
    for n in range(5):
        c.part('TailFeather',((n-2)*.35,2.7,2.5),(.35,.6,3.2),accent,rotation=(-20,(n-2)*10,0),wedge=True)
    return c


def build():
    document=E.Element('roblox',version='4');folder=make(document,'Folder','CreatureMounts')
    c=dragon(folder,'Mallow','278DC4','86DDFC','E3FCFF');c.finish()
    c=quadruped(folder,'PuddlePup','217F86','62DAD4','B4FFFF')
    c.tail([(0,2.6,2.3),(.4,3.2,3.8),(1.2,4.1,4.6)],width=.8)
    for n in range(6):
        a=n*math.tau/6;c.part('WaterOrb',(math.cos(a)*3.3,3.2+math.sin(a)*.8,math.sin(a)*3),(.62,.62,.62),'A8F9FF',rotation=(35,n*25,25),neon=True)
    c.finish()
    c=quadruped(folder,'AeroKitty','B96519','FBC76E','FFF7CE');c.wings(feather=True,span=6.5,rise=5.6)
    c.tail([(0,2.5,2.4),(1,3,3.7),(1.9,4.3,4.5),(2.1,5.1,4.6)],tip='FFD16D')
    c.finish()
    c=Creature(folder,'LeafGecko','388927','8FD44A','C5FF79')
    c.part('VoxelBody',(0,2.2,0),(3.6,1.7,5.2),c.body)
    c.part('VoxelHead',(0,2.7,-3.2),(3.1,1.4,2.2),c.accent)
    for side in (-1,1):
        c.part('VoxelEye',(side*1.55,2.95,-3.65),(.12,.45,.6),c.glow,neon=True)
        for z in (-1.8,1.6):
            c.part('BentGeckoLeg',(side*2.15,1.35,z),(1.1,1.6,.7),c.body)
            c.part('GeckoFoot',(side*2.5,.38,z-.2),(1.1,.55,1.3),c.accent)
            for toe in range(3):c.part('SquareToe',(side*(2.15+toe*.32),.22,z-.95),(.25,.35,.6),c.glow)
        for n in range(5):c.part('SideGlow',(side*1.85,2.25,-1.5+n*.8),(.12,.35,.35),'90FFE6',neon=True)
    c.tail([(0,2.1,2.3),(0,1.8,4),(.8,1.3,5.5),(1.5,.9,6.6)],width=1.4,tip='86DB3F')
    c.crystals(7,4.2,'BEFF65',y=3);c.finish((0,3.35,.2))
    c=bird(folder,'EmberChick','943A13','F38D22','FFE888')
    for n in range(6):
        a=n*math.tau/6;c.rod('LavaVein',(math.cos(a)*1.5,2.2,math.sin(a)*1.5),(math.cos(a+.4)*1.4,3.8,math.sin(a+.4)*1.4),.1,'FFBC2F',True)
    c.finish((0,3.65,.55))
    c=Creature(folder,'StarBunny','E8D9EB','F2ABDA','FFF0BC')
    c.part('VoxelHaunch',(0,1.6,.5),(2.8,2.3,3),c.body);c.part('VoxelChest',(0,2.9,-.5),(2,2.7,2.1),WHITE)
    c.part('VoxelHead',(0,4.3,-1.3),(2.2,2,1.9),c.accent)
    for side in (-1,1):
        c.part('RabbitEar',(side*.65,6.1,-1.1),(.65,2.4,.6),WHITE,rotation=(0,0,side*-12))
        c.part('EarPink',(side*.65,6.1,-1.43),(.3,1.6,.08),c.accent,rotation=(0,0,side*-12))
        c.part('RabbitEye',(side*.55,4.6,-2.3),(.28,.4,.1),WHITE,neon=True)
        c.part('RabbitFoot',(side*1.1,.4,-.2),(1,.7,2.5),WHITE)
        c.rod('Antler',(side*.75,5.2,-.9),(side*1.6,7.8,-.7),.16,WHITE)
        for n in range(3):
            center=(side*(1.15+n*.28),6.8+n*.45,-.7)
            c.rod('AntlerTwig',(side*1.2,6.8,-.7),center,.1,WHITE)
            for p in range(4):
                a=p*math.tau/4;c.part('Blossom',(center[0]+math.cos(a)*.32,center[1]+math.sin(a)*.24,center[2]),(.45,.35,.48),'FFD0EC',rotation=(0,p*45,25),wedge=True)
    c.part('RabbitNose',(0,4.05,-2.33),(.4,.3,.15),'EF80BB')
    c.part('StarTail',(0,1.8,2.3),(.9,.9,.9),WHITE,rotation=(0,45,45),neon=True)
    c.finish((0,3.55,1))
    c=quadruped(folder,'StormFox','202B65','D8D9C7','FFF0A3')
    for side in (-1,0,1):
        c.tail([(side*.55,2.5,2),(side*1.3,3.5,3.7),(side*2,5.6,4.5),(side*2.1,7.1,4.2)],width=.95,tip=WHITE)
    for side in (-1,1):
        c.horn((side*.7,4.8,-2.7),(side*1.1,6.2,-1.6),'F5DB72')
        c.rod('LightningBrow',(side*.2,4.7,-3.8),(side*1.05,4.6,-3.6),.13,'FFF0AA',True)
    c.finish()
    c=Creature(folder,'CloudSerpent','176F74','7CCFC0','FFF6A6')
    for n in range(14):
        a=n*math.tau/14
        c.part('Coil',(math.cos(a)*1.9,1.2,math.sin(a)*1.9),(1.3,1.6,1.5),c.body,rotation=(0,-math.degrees(a),0))
        if n%3==0:c.part('CoilGoldBand',(math.cos(a)*1.94,1.25,math.sin(a)*1.94),(1.34,.14,1.54),GOLD,rotation=(0,-math.degrees(a),0))
    for n in range(6):
        c.part('SerpentNeck',(.3,2.1+n*.65,-1.6),(.95,1,.95),c.body,rotation=(0,n*12,0))
        if n%2==0:c.part('NeckBand',(.3,2.1+n*.65,-1.6),(1.05,.15,1.05),GOLD)
    c.head((.3,6.6,-2),(1.6,1.5,2.1),ears=False)
    for side in (-1,1):
        c.horn((side*.5,7.1,-1.8),(side*1,8.8,-1.1),GOLD)
        c.rod('Whisker',(side*.5,6.4,-3.1),(side*2.1,6,-3.3),.08,GOLD)
    for n in range(5):c.part('CloudScale',((-1 if n%2 else 1)*1.5,2.2,-1+n*.55),(.8,.6,.7),WHITE,rotation=(0,35*n,20),wedge=True)
    c.finish((0,2.8,.65))
    c=quadruped(folder,'CrystalOtter','372263','9370D2','E9C3FF');c.crystals(9,4.4,'A966EF',y=3.9)
    c.tail([(0,2.5,2.4),(0,2,4.2),(.7,2.7,5.8)],width=1.1,tip='C58DFF')
    for side in (-1,1):
        for n in range(3):c.rod('OtterWhisker',(side*.8,3.6,-3.6),(side*(1.9+n*.25),3.6+n*.15,-3.7),.045,'D9B8FF',True)
    c.finish()
    c=quadruped(folder,'RocketRaccoon','583C3C','AEAEAD','FFE8B5')
    for side in (-1,1):c.part('EyeMask',(side*.7,4.1,-3.55),(.85,.85,.26),'211F2A')
    # Re-add the bright eyes over the dark mask.
    for side in (-1,1):c.part('RingtailEye',(side*.7,4.2,-3.75),(.22,.32,.1),c.glow,neon=True)
    c.tail([(0,2.4,2.2),(0,3.2,3.6),(0,5,4.6),(0,6.8,4.9)],width=1.15)
    for n in range(4):c.part('TailArmorBand',(0,3.1+n*.8,3.6+n*.4),(1.2,.3,1),c.accent,rotation=(15,0,0))
    for side in (-1,1):c.part('RocketFin',(side*.6,5.8,4.8),(.5,1.6,.9),'C6502E',rotation=(0,0,side*30),wedge=True)
    c.part('Afterburner',(0,7.6,5),(.55,2.2,.55),'FFD58A',wedge=True,neon=True)
    c.finish()
    c=quadruped(folder,'AuroraLynx','28527A','8870CE','BCFCFF')
    for side in (-1,1):
        for n in range(7):
            c.part('AuroraMane',(side*(1.1+n*.14),4.6+(n%3)*.3,-1.9+n*.32),(.35,1.2+(n%4)*.35,.65),'B38DF2' if n%2 else '71EBF3',rotation=(-25,side*35,side*-32),wedge=True,neon=n%3==0)
        c.rod('ChestLightning',(side*.8,3.7,-1.5),(side*1.5,2.6,-1),.12,'9DFFFF',True)
    c.tail([(0,2.4,2.3),(0,2.4,4.1),(1.2,3.3,5.4),(1.5,4.5,5.7)],tip='B58AFA')
    c.finish()
    c=dragon(folder,'NeonWyvern','211331','9F20E0','FF69EF',neon=True)
    for n in range(4):c.rod('VoidVein',(-1.4,2.9,-1+n*.7),(-1,3.5,-.7+n*.7),.1,'D24AFF',True)
    c.finish()
    c=Creature(folder,'SolarManta','BA781E','F5CA52','FFF1A7')
    c.facet_body((0,2.7,0),(3,1.3,4))
    for side in (-1,1):
        c.part('MantaWing',(side*3.6,2.7,.1),(5.5,.4,3.6),GOLD,rotation=(0,side*12,side*5),wedge=True)
        c.rod('MantaWingRim',(side*1.2,2.9,-1.5),(side*6,3.1,1),.1,'FFE68A',True)
    c.tail([(0,2.8,2),(0,3.1,4),(.7,3.8,6)],width=.3,tip=GOLD)
    # Sun crown is a hollow polygon ring behind the saddle, not an occluding disc.
    for n in range(16):
        a=n*math.tau/16;b=(n+1)*math.tau/16
        c.rod('SolarCrown',(math.cos(a)*3.5,6+math.sin(a)*3.5,2.6),(math.cos(b)*3.5,6+math.sin(b)*3.5,2.6),.18,'FFE48A',True)
        c.rod('SolarRay',(math.cos(a)*3.7,6+math.sin(a)*3.7,2.6),(math.cos(a)*(4.6 if n%2 else 5.1),6+math.sin(a)*(4.6 if n%2 else 5.1),2.6),.16,GOLD,True)
    c.finish((0,3.5,-.4))
    c=Creature(folder,'ThunderHydra','343A72','887F78','FFE68A')
    c.facet_body((0,2.6,.5),(3.9,2.8,5));c.legs(width=1.45,front=-1.4,rear=2)
    for side in (-1,0,1):
        c.rod('HydraNeck',(side*.9,3.5,-1.4),(side*1.7,5.4+(1 if side==0 else 0),-2.3),.85,c.body)
        c.head((side*1.8,5.9+(1 if side==0 else 0),-2.6),(1.5,1.3,2),ears=False)
        for horn in (-1,1):c.horn((side*1.8+horn*.45,6.4+(1 if side==0 else 0),-2.2),(side*1.8+horn*.85,7.6+(1 if side==0 else 0),-1),GOLD)
    c.wings(span=5.8,rise=2,tint='4349B6')
    c.tail([(0,2.5,2.8),(0,2.6,4.7),(1.5,2.8,6.2)],width=1)
    c.finish((0,4,.8))
    c=bird(folder,'QuantumPhoenix','175F7E','BB5DCE','B8FCFF');c.finish((0,3.7,.6))
    c=Creature(folder,'CosmicLeviathan','222261','5752D7','F3EFFF')
    c.facet_body((0,3,.3),(4.4,3.4,10));c.part('WhaleBelly',(0,2.1,-1),(3.5,.6,7),'7F78BC',wedge=True)
    for side in (-1,1):
        c.part('WhaleFin',(side*3.2,2.5,-.3),(3.7,.5,2.4),'6A5CDB',rotation=(0,side*35,side*8),wedge=True)
        c.part('WhaleEye',(side*1.65,3.7,-4.4),(.5,.55,.25),WHITE,neon=True)
        c.horn((side*.8,4.6,-3.3),(side*2.6,6,-4.1),'D9C9FF')
        for n in range(6):
            pos=(side*1.9,3.9+math.sin(n)*.4,-3+n*1.25)
            c.part('ConstellationStar',pos,(.2,.2,.2),WHITE,rotation=(0,0,45),neon=True)
            if n:c.rod('ConstellationLine',(side*1.9,3.9+math.sin(n-1)*.4,-3+(n-1)*1.25),pos,.035,'BDB6FF',True)
    c.tail([(0,3,4.5),(0,3.2,6.3),(0,4.1,8.2)],width=1.5)
    for side in (-1,1):c.part('WhaleFluke',(side*1.8,4,8.2),(3.8,.6,2.4),'4740C5',rotation=(0,side*22,0),wedge=True)
    c.finish((0,4.65,-.2))
    target=ROOT/'assets/CreatureMounts.rbxmx';target.parent.mkdir(exist_ok=True)
    E.indent(document)
    E.ElementTree(document).write(target,encoding='utf-8',xml_declaration=False)
    for key,count in COUNTS.items():print(f'{key}: {count} parts')
    print(f'Total: {sum(COUNTS.values())} parts across {len(COUNTS)} templates -> {target}')
    return target


if __name__=='__main__':
    build()
