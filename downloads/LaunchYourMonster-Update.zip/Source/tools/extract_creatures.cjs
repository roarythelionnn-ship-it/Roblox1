/* Export the user's original Three.js creature geometry without a browser/renderer.
 * node tools/extract_creatures.cjs path/to/three.js path/to/showcase-engine.js [output.json]
 * Runs source builders in a VM without fs/network access. All static mesh triangles,
 * world transforms, normals, vertex colors and alpha are preserved. Front +Z is
 * rotated to Roblox -Z; uniform scaling and floor normalization are explicit.
 */
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { performance } = require('node:perf_hooks');
const [threePath, enginePath, outputPath = path.join(__dirname, '../assets/exact_creatures.json')] = process.argv.slice(2);
if (!threePath || !enginePath) throw new Error('Usage: node tools/extract_creatures.cjs three.js showcase-engine.js [output.json]');
const ctx = { console, performance, window: {}, document: { readyState: 'loading', addEventListener() {} }, Math };
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(threePath, 'utf8'), ctx, { timeout: 10000 });
ctx.window.THREE = ctx.THREE;
vm.runInContext(fs.readFileSync(enginePath, 'utf8'), ctx, { timeout: 10000 });
const T = ctx.THREE;
const L = ctx.window.LYM;
const IDS = {
  mallow: 'Mallow', puddlePup: 'PuddlePup', aeroKitty: 'AeroKitty', leafGecko: 'LeafGecko',
  emberChick: 'EmberChick', starBunny: 'StarBunny', stormFox: 'StormFox', cloudSerpent: 'CloudSerpent',
  crystalOtter: 'CrystalOtter', rocketRingtail: 'RocketRaccoon', auroraLynx: 'AuroraLynx',
  neonWyvern: 'NeonWyvern', solarManta: 'SolarManta', thunderHydra: 'ThunderHydra',
  quantumPhoenix: 'QuantumPhoenix', cosmicLeviathan: 'CosmicLeviathan',
};
const round = v => Math.round(v * 1000000) / 1000000;
const clamp = v => Math.max(0, Math.min(1, v));
const linearToSrgb = v => v <= .0031308 ? v * 12.92 : 1.055 * Math.pow(v, 1 / 2.4) - .055;
const result = { version: 1, source: 'User-supplied LAUNCH YOUR MONSTER Three.js r160 showcase engine', scale: 2.6,
  front: '-Z', pose: 'builder rest pose, prior to animation callbacks', creatures: [] };
for (const sourceId of L.ORDER) {
  const definition = L.PETS[sourceId];
  const object = definition.build({ anim: [], def: definition });
  object.updateMatrixWorld(true);
  const sourceBounds = new T.Box3().setFromObject(object);
  const factor = 2.6;
  const transform = p => [-p.x * factor, (p.y - sourceBounds.min.y) * factor, -p.z * factor].map(round);
  const groups = new Map();
  let meshCount = 0, triangleCount = 0;
  let bodyTop = -Infinity;
  object.traverse(mesh => {
    if (!mesh.isMesh || !mesh.geometry.attributes.position) return;
    meshCount++;
    const geom = mesh.geometry;
    const position = geom.attributes.position;
    const normals = geom.attributes.normal;
    const vertexColors = geom.attributes.color;
    const normalMatrix = new T.Matrix3().getNormalMatrix(mesh.matrixWorld);
    const index = geom.index;
    const materials = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
    const ranges = geom.groups.length && Array.isArray(mesh.material) ? geom.groups : [{ start: 0, count: index ? index.count : position.count, materialIndex: 0 }];
    for (const range of ranges) {
      const material = materials[range.materialIndex || 0];
      const opacity = material.opacity ?? 1;
      const neon = material.isMeshBasicMaterial || ((material.emissiveIntensity || 0) > .65 && material.emissive && material.emissive.getHex() !== 0);
      const key = `${neon ? 'neon' : 'solid'}:${round(opacity)}`;
      if (!groups.has(key)) groups.set(key, { neon, opacity: round(opacity), p: [], c: [], ci: [], t: [], lookup: new Map(), colorLookup: new Map() });
      const group = groups.get(key);
      const getVertex = id => {
        const p = new T.Vector3().fromBufferAttribute(position, id).applyMatrix4(mesh.matrixWorld);
        const normal = normals ? new T.Vector3().fromBufferAttribute(normals, id).applyMatrix3(normalMatrix).normalize() : new T.Vector3(0, 1, 0);
        const pv = transform(p);
        const nv = [-normal.x, normal.y, -normal.z].map(round);
        let tint = (material.color || new T.Color(1, 1, 1)).clone();
        if (vertexColors && material.vertexColors) tint.multiply(new T.Color(vertexColors.getX(id), vertexColors.getY(id), vertexColors.getZ(id)));
        const cv = [tint.r, tint.g, tint.b].map(v => round(clamp(linearToSrgb(v))));
        const vertexKey = [...pv, ...cv].join(',');
        let out = group.lookup.get(vertexKey);
        if (out === undefined) {
          out = group.p.length / 3;
          group.lookup.set(vertexKey, out);
          group.p.push(...pv);
          const colorKey=cv.join(',');let colorId=group.colorLookup.get(colorKey);
          if(colorId===undefined){colorId=group.c.length/3;group.colorLookup.set(colorKey,colorId);group.c.push(...cv)}
          group.ci.push(colorId);
        }
        return out;
      };
      for (let i = range.start; i < range.start + range.count; i += 3) {
        const ids = [0,1,2].map(k => index ? index.getX(i+k) : i+k);
        const points = ids.map(id => transform(new T.Vector3().fromBufferAttribute(position,id).applyMatrix4(mesh.matrixWorld)));
        const midX = points.reduce((s,p) => s+p[0],0)/3;
        const midZ = points.reduce((s,p) => s+p[2],0)/3;
        // Highest central body surface, excluding wings/tails/heads and tiny crack overlays.
        if (!neon && Math.abs(midX) < .48 && Math.abs(midZ) < .52) bodyTop = Math.max(bodyTop,...points.map(p=>p[1]));
        group.t.push(...ids.map(getVertex)); triangleCount++;
      }
    }
  });
  const bounds = [transform(new T.Vector3(sourceBounds.max.x,sourceBounds.min.y,sourceBounds.max.z)),
    transform(new T.Vector3(sourceBounds.min.x,sourceBounds.max.y,sourceBounds.min.z))];
  const height=bounds[1][1];
  // Keep each saddle on the trunk rather than the top of a vertical neck/sun crown.
  const seatOverrides = { CloudSerpent: [-2.2, 2.15, .2], StarBunny: [0,2.8,.25], NeonWyvern: [0,5.1,.5], SolarManta: [0,1.6,.1], CosmicLeviathan: [0,3.6,0], ThunderHydra: [0,3.1,.45] };
  const seat = seatOverrides[IDS[sourceId]] || [0, Math.max(1.6, Math.min(bodyTop + .08, height*.65)), 0];
  const data = { id: IDS[sourceId], sourceId, name: definition.name, bounds, seat: seat.map(round),
    sourceMeshes: meshCount, triangles: triangleCount,
    groups: [...groups.values()].map(({lookup,colorLookup,...group}) => group) };
  result.creatures.push(data);
  console.log(`${data.id}: ${meshCount} source meshes, ${triangleCount} triangles -> ${data.groups.length} material batches, seat ${data.seat.join(',')}`);
}
fs.mkdirSync(path.dirname(outputPath),{recursive:true});
fs.writeFileSync(outputPath,JSON.stringify(result));
console.log(`Exported ${result.creatures.length} exact static creature geometries to ${outputPath}`);
