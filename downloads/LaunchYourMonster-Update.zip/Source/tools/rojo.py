"""Download verified Rojo 7.7.1 and run it from the repository root."""
import hashlib
import io
import json
from pathlib import Path
import platform
import subprocess
import sys
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]
VERSION = "7.7.1"


def main():
    system = platform.system()
    machine = platform.machine().lower()
    arch = {"amd64": "x86_64", "arm64": "aarch64"}.get(machine, machine)
    target = {"Linux": "linux", "Darwin": "macos", "Windows": "windows"}.get(system)
    name = f"rojo-{VERSION}-{target}-{arch}.zip"
    hashes = json.loads((ROOT / "tools/rojo-hashes.json").read_text())
    if name not in hashes:
        raise RuntimeError(f"Unsupported platform: {system}/{arch}")
    archive = ROOT / ".tools" / name
    binary_name = "rojo.exe" if system == "Windows" else "rojo"
    binary = archive.parent / name.removesuffix(".zip") / binary_name
    if not archive.exists():
        url = f"https://github.com/rojo-rbx/rojo/releases/download/v{VERSION}/{name}"
        print(f"Downloading {url}", flush=True)
        with urllib.request.urlopen(url, timeout=90) as response:
            data = response.read()
        if hashlib.sha256(data).hexdigest() != hashes[name]:
            raise RuntimeError("Rojo download checksum mismatch")
        archive.parent.mkdir(parents=True, exist_ok=True)
        archive.write_bytes(data)
    data = archive.read_bytes()
    if hashlib.sha256(data).hexdigest() != hashes[name]:
        raise RuntimeError(f"Rojo cache checksum mismatch; remove {archive} and retry")
    # Extract only the executable, never arbitrary archive paths.
    with zipfile.ZipFile(io.BytesIO(data)) as package:
        executable = package.read(binary_name)
    binary.parent.mkdir(parents=True, exist_ok=True)
    if not binary.exists() or binary.read_bytes() != executable:
        binary.write_bytes(executable)
    if system != "Windows":
        binary.chmod(0o755)
    args = sys.argv[1:] or ["serve"]
    if args[0] == "build":
        (ROOT / "build").mkdir(exist_ok=True)
    return subprocess.call([str(binary), *args], cwd=ROOT)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        sys.exit(130)
    except (OSError, RuntimeError, zipfile.BadZipFile) as error:
        print(f"Rojo: {error}", file=sys.stderr)
        sys.exit(1)
