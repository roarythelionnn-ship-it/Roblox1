"""Export exact extracted showcase triangle geometry to portable glTF 2.0 GLB files.
No mesh upload or Roblox asset ID is required to produce these files.
"""
from pathlib import Path
import json, math, struct
ROOT=Path(__file__).resolve().parents[1]

def export(spec, destination):
 data=bytearray();views=[];accessors=[];primitives=[];materials=[]
 def accessor(values,fmt,kind,width,component,extents=False):
  while len(data)%4:data.append(0)
  start=len(data);data.extend(struct.pack('<'+fmt*len(values),*values))
  views.append({'buffer':0,'byteOffset':start,'byteLength':len(data)-start})
  entry={'bufferView':len(views)-1,'componentType':component,'count':len(values)//width,'type':kind}
  if extents:
   entry['min']=[min(values[i::width]) for i in range(width)];entry['max']=[max(values[i::width]) for i in range(width)]
  accessors.append(entry);return len(accessors)-1
 for index, group in enumerate(spec['groups']):
  positions=[];colors=[];normals=[]
  source=group['p'];palette=group['c'];ci=group['ci'];triangles=group['t']
  for t in range(0,len(triangles),3):
   ids=triangles[t:t+3]
   xyz=[source[i*3:i*3+3] for i in ids]
   u=[b-a for a,b in zip(xyz[0],xyz[1])];v=[b-a for a,b in zip(xyz[0],xyz[2])]
   n=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]]
   length=math.sqrt(sum(a*a for a in n));n=[a/length for a in n] if length>1e-12 else [0,1,0]
   for vid,p in zip(ids,xyz):positions.extend(p);colors.extend((x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4) for x in palette[ci[vid]*3:ci[vid]*3+3]);normals.extend(n)
  mat={'name':'Glow' if group['neon'] else 'Surface','pbrMetallicRoughness':{'baseColorFactor':[1,1,1,group['opacity']],'metallicFactor':0,'roughnessFactor':.75},'doubleSided':True}
  if group['opacity']<1:mat['alphaMode']='BLEND'
  if group['neon']:mat['emissiveFactor']=[1,1,1];mat['extensions']={'KHR_materials_unlit':{}}
  materials.append(mat)
  primitives.append({'attributes':{'POSITION':accessor(positions,'f','VEC3',3,5126,True),'NORMAL':accessor(normals,'f','VEC3',3,5126),'COLOR_0':accessor(colors,'f','VEC3',3,5126)},'mode':4,'material':index})
 doc={'asset':{'version':'2.0','generator':'LaunchYourMonster exact showcase exporter'},'scene':0,'scenes':[{'nodes':[0]}],
  'nodes':[{'name':spec['id'],'mesh':0,'extras':{'RideSeat':spec['seat'],'sourceId':spec['sourceId']}}],
  'meshes':[{'name':spec['name'],'primitives':primitives}], 'materials':materials,'buffers':[{'byteLength':len(data)}],
  'bufferViews':views,'accessors':accessors,'extensionsUsed':['KHR_materials_unlit']}
 encoded=json.dumps(doc,separators=(',',':')).encode();encoded+=b' '*((-len(encoded))%4);data+=b'\0'*((-len(data))%4)
 total=12+8+len(encoded)+8+len(data)
 destination.write_bytes(struct.pack('<III',0x46546c67,2,total)+struct.pack('<I4s',len(encoded),b'JSON')+encoded+struct.pack('<I4s',len(data),b'BIN\0')+data)

if __name__=='__main__':
 dest=ROOT/'build/ExactCreatureModels';dest.mkdir(parents=True,exist_ok=True)
 creatures=json.loads((ROOT/'assets/exact_creatures.json').read_text())['creatures']
 for spec in creatures:export(spec,dest/(spec['id']+'.glb'))
 print(f'Exported {len(creatures)} original-geometry GLB models to {dest}')
