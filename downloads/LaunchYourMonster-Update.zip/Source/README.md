# LAUNCH YOUR MONSTER! — überarbeitete Spiel-Datei

Die aktuelle Datei ist **`build/LaunchYourMonster-Updated.rbxlx`**.
Öffne sie lokal in Roblox Studio über **Datei → Aus Datei öffnen**.
Der Spawn ist im Edit-Modus sichtbar; Reiten und Spielfunktionen starten mit Play.

- **R / Controller Y / RIDE:** auf das ausgerüstete Tier steigen oder absteigen.
- **WASD / Stick / Handy-Joystick:** in der Plaza reiten.
- **LAUNCH!** bei der Kanone: starten, während der Spieler auf seinem Tier sitzt.
- Die Originalgeometrien aller 16 Tiere sind enthalten; bei fehlender Mesh-API
  bleiben native Ersatzmodelle aktiv. Originale als GLB: `build/ExactCreatureModels`.

[Lokale Studio-Verbindung und Übergabe an einen neuen Chat](docs/LOCAL_HANDOFF.md)

[Änderungen, ausgeführte Tests und offene Studio-Prüfungen](docs/UPDATED_GAME_STATUS.md)

[Herkunft und Genauigkeit der Tiermodelle](docs/CREATURE_ART.md)

Deine hochgeladene Originaldatei wurde nicht überschrieben. Es wurde nichts
veröffentlicht. Der aktuelle Stand ist noch nicht in der Roblox-Engine getestet.

Der frühere Rojo-Prototyp unter `src`, `assets/LaunchPlaza.rbxmx` und
`default.project.json` bleibt getrennt erhalten. Seine ursprüngliche Anleitung
steht in `docs/INITIAL_PROTOTYPE_SETUP.md`. Diesen Prototyp nicht über die neue
vollständige Spiel-Datei synchronisieren.
