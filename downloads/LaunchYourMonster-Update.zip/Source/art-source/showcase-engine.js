/* LAUNCH YOUR MONSTER! — 3D pet showcase engine (core). Requires THREE (r160 UMD) and LYM_PP. */
(function () {
'use strict';
const T = window.THREE;
const PP = window.LYM_PP;
const L = (window.LYM = window.LYM || {});

const V = (x, y, z) => new T.Vector3(x, y, z);
L.V = V;

function rng(seed) {
  let s = (Math.imul(seed | 0, 2654435761) >>> 0) || 1;
  return () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; };
}
L.rng = rng;

// ---------- materials ----------
function M(color, o = {}) {
  return new T.MeshStandardMaterial({
    color, roughness: o.r ?? 0.62, metalness: o.m ?? 0.05, flatShading: o.flat ?? true,
    emissive: o.e ?? 0x000000, emissiveIntensity: o.ei ?? 1,
    transparent: o.op != null, opacity: o.op ?? 1, side: T.DoubleSide, vertexColors: !!o.vc,
    depthWrite: o.dw ?? true
  });
}
function G(color, k = 3, o = {}) {
  const c = new T.Color(color).multiplyScalar(k);
  return new T.MeshBasicMaterial({ color: c, side: T.DoubleSide, transparent: o.op != null, opacity: o.op ?? 1,
    blending: o.add ? T.AdditiveBlending : T.NormalBlending, depthWrite: o.add ? false : true, vertexColors: !!o.vc });
}
const GOLD = () => M(0xE8B13A, { r: 0.32, m: 0.85 });
const BONE = () => M(0xF4EEDC, { r: 0.45 });
L.M = M; L.G = G; L.GOLD = GOLD; L.BONE = BONE;

// ---------- geometry helpers ----------
function jitter(geo, amt, seed) {
  if (geo.index) geo = geo.toNonIndexed();
  const p = geo.attributes.position, r = rng(seed || 7), map = new Map();
  for (let i = 0; i < p.count; i++) {
    const k = Math.round(p.getX(i) * 997) + ',' + Math.round(p.getY(i) * 997) + ',' + Math.round(p.getZ(i) * 997);
    let d = map.get(k);
    if (!d) { d = [(r() - 0.5) * amt, (r() - 0.5) * amt, (r() - 0.5) * amt]; map.set(k, d); }
    p.setXYZ(i, p.getX(i) + d[0], p.getY(i) + d[1], p.getZ(i) + d[2]);
  }
  geo.computeVertexNormals();
  return geo;
}
function shadowy(m) { m.castShadow = true; m.receiveShadow = true; return m; }
function blob(sx, sy, sz, mat, o = {}) {
  const g = jitter(new T.IcosahedronGeometry(1, o.d ?? 1), o.j ?? 0.14, o.seed ?? 3);
  g.scale(sx, sy, sz);
  return shadowy(new T.Mesh(g, mat));
}
function box(sx, sy, sz, mat, o = {}) {
  let g = new T.BoxGeometry(sx, sy, sz);
  if (o.j) g = jitter(g, o.j, o.seed ?? 5);
  return shadowy(new T.Mesh(g, mat));
}
function aim(obj, dir) { obj.quaternion.setFromUnitVectors(V(0, 1, 0), dir.clone().normalize()); return obj; }
function spike(r, h, mat, seg = 4) {
  const g = new T.ConeGeometry(r, h, seg, 1); g.translate(0, h / 2, 0);
  return shadowy(new T.Mesh(g, mat));
}
function crystal(r, h, mat, seg = 5) {
  const g = new T.CylinderGeometry(0, r, h * 0.7, seg, 1); g.translate(0, h * 0.35 + h * 0.15, 0);
  const g2 = new T.CylinderGeometry(r, r * 0.55, h * 0.15, seg, 1); g2.translate(0, h * 0.075, 0);
  const grp = new T.Group();
  grp.add(shadowy(new T.Mesh(g, mat)), shadowy(new T.Mesh(g2, mat)));
  return grp;
}
function limb(a, b, r0, r1, mat, seg = 6) {
  const len = a.distanceTo(b);
  const g = new T.CylinderGeometry(r1, r0, len, seg, 1); g.translate(0, len / 2, 0);
  const m = shadowy(new T.Mesh(g, mat)); m.position.copy(a); aim(m, b.clone().sub(a));
  return m;
}
function put(parent, obj, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0) {
  obj.position.set(x, y, z); obj.rotation.set(rx, ry, rz); parent.add(obj); return obj;
}
// Tapered tube along a CatmullRom curve. rFn(t) radius; colorFn(t, radialDir) -> Color.
function tube(pts, rFn, mat, o = {}) {
  const seg = o.seg ?? 6, steps = o.steps ?? 48;
  const curve = new T.CatmullRomCurve3(pts, false, 'catmullrom', o.tension ?? 0.5);
  const frames = curve.computeFrenetFrames(steps, false);
  if (o.up) { // stable frames using an up vector instead of Frenet
    for (let i = 0; i <= steps; i++) {
      const tg = frames.tangents[i];
      const b = new T.Vector3().crossVectors(tg, o.up).normalize();
      if (b.lengthSq() < 1e-6) b.set(1, 0, 0);
      frames.binormals[i] = b; frames.normals[i] = new T.Vector3().crossVectors(b, tg).normalize();
    }
  }
  const pos = [], col = [], idx = [];
  const rot = o.rot ?? 0;
  for (let i = 0; i <= steps; i++) {
    const t = i / steps, P = curve.getPointAt(t), N = frames.normals[i], B = frames.binormals[i], r = rFn(t);
    for (let j = 0; j < seg; j++) {
      const a = j / seg * Math.PI * 2 + rot, c = Math.cos(a), s = Math.sin(a);
      const d = V(N.x * c + B.x * s, N.y * c + B.y * s, N.z * c + B.z * s);
      pos.push(P.x + d.x * r, P.y + d.y * r, P.z + d.z * r);
      if (o.colorFn) { const cc = o.colorFn(t, d, j); col.push(cc.r, cc.g, cc.b); }
    }
  }
  for (let i = 0; i < steps; i++) for (let j = 0; j < seg; j++) {
    const a = i * seg + j, b = i * seg + (j + 1) % seg, c = (i + 1) * seg + j, d = (i + 1) * seg + (j + 1) % seg;
    idx.push(a, c, b, b, c, d);
  }
  // caps
  const addCap = (ring, t) => {
    const P = curve.getPointAt(t); const ci = pos.length / 3; pos.push(P.x, P.y, P.z);
    if (o.colorFn) { const cc = o.colorFn(t, V(0, 1, 0), 0); col.push(cc.r, cc.g, cc.b); }
    for (let j = 0; j < seg; j++) idx.push(ci, ring * seg + j, ring * seg + (j + 1) % seg);
  };
  addCap(0, 0); addCap(steps, 1);
  const g = new T.BufferGeometry();
  g.setAttribute('position', new T.Float32BufferAttribute(pos, 3));
  if (o.colorFn) g.setAttribute('color', new T.Float32BufferAttribute(col, 3));
  g.setIndex(idx); g.computeVertexNormals();
  const m = shadowy(new T.Mesh(g, mat));
  m.userData.curve = curve; m.userData.frames = frames;
  return m;
}
// Glowing crack network painted onto the outer surface of `target` (raycast from outside toward `center`, local to target's parent space).
function cracks(target, n, mat, o = {}) {
  const r = rng(o.seed ?? 11), ray = new T.Raycaster(), grp = new T.Group();
  target.updateWorldMatrix(true, false);
  const center = new T.Vector3(); new T.Box3().setFromObject(target).getCenter(center);
  const inv = new T.Matrix4().copy(target.matrixWorld).invert();
  const yMin = o.yMin ?? -0.7, yMax = o.yMax ?? 0.9;
  for (let k = 0; k < n; k++) {
    let th = r() * Math.PI * 2, y = yMin + r() * (yMax - yMin);
    const pts = []; const len = (o.len ?? 7) + Math.floor(r() * 3);
    let dth = (r() - 0.5) * 0.5, dy = (r() - 0.5) * 0.25;
    for (let s = 0; s < len; s++) {
      const cy = Math.max(-0.98, Math.min(0.98, y)), rr = Math.sqrt(1 - cy * cy);
      const dir = V(Math.cos(th) * rr, cy, Math.sin(th) * rr);
      ray.set(center.clone().add(dir.clone().multiplyScalar(30)), dir.clone().negate());
      const hit = ray.intersectObject(target, false)[0];
      if (hit) {
        const nrm = hit.face.normal.clone().transformDirection(target.matrixWorld);
        pts.push(hit.point.clone().add(nrm.multiplyScalar(0.012)).applyMatrix4(inv));
      }
      th += dth + (r() - 0.5) * 0.35 * (o.step ?? 1); y += dy + (r() - 0.5) * 0.18 * (o.step ?? 1);
      if (r() < 0.25 && pts.length > 2) { // branch
        const bp = pts.slice(-2);
        const bdir = th + (r() < 0.5 ? 0.8 : -0.8);
        const cy2 = Math.max(-0.98, Math.min(0.98, y + 0.2)), rr2 = Math.sqrt(1 - cy2 * cy2);
        const d2 = V(Math.cos(bdir) * rr2, cy2, Math.sin(bdir) * rr2);
        ray.set(center.clone().add(d2.clone().multiplyScalar(30)), d2.clone().negate());
        const h2 = ray.intersectObject(target, false)[0];
        if (h2) {
          const n2 = h2.face.normal.clone().transformDirection(target.matrixWorld);
          bp.push(h2.point.clone().add(n2.multiplyScalar(0.012)).applyMatrix4(inv));
          grp.add(tube(bp, t => (o.w ?? 0.022) * 0.8 * (1 - t * 0.6), mat, { seg: 3, steps: 6 }));
        }
      }
    }
    if (pts.length >= 3) grp.add(tube(pts, t => (o.w ?? 0.022) * (1 - Math.abs(t - 0.4) * 0.9), mat, { seg: 3, steps: pts.length * 3 }));
  }
  grp.traverse(c => { c.castShadow = false; c.receiveShadow = false; });
  target.add(grp);
  return grp;
}
L.jitter = jitter; L.blob = blob; L.box = box; L.aim = aim; L.spike = spike; L.crystal = crystal;
L.limb = limb; L.put = put; L.tube = tube; L.cracks = cracks;

// ---------- particles ----------
let _spark;
function sparkTex() {
  if (_spark) return _spark;
  const c = document.createElement('canvas'); c.width = c.height = 64;
  const x = c.getContext('2d'); const g = x.createRadialGradient(32, 32, 0, 32, 32, 32);
  g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(0.25, 'rgba(255,255,255,0.85)');
  g.addColorStop(0.6, 'rgba(255,255,255,0.18)'); g.addColorStop(1, 'rgba(255,255,255,0)');
  x.fillStyle = g; x.fillRect(0, 0, 64, 64);
  _spark = new T.CanvasTexture(c); return _spark;
}
let _petal;
function petalTex() {
  if (_petal) return _petal;
  const c = document.createElement('canvas'); c.width = c.height = 64;
  const x = c.getContext('2d'); x.fillStyle = '#fff';
  x.translate(32, 32); x.rotate(0.6); x.fillRect(-14, -9, 28, 18);
  _petal = new T.CanvasTexture(c); return _petal;
}
// kind: 'rise' (drift up), 'orbit', 'fall'
function particles(n, o = {}) {
  const r = rng(o.seed ?? 21), pos = new Float32Array(n * 3), sp = [];
  const R = o.radius ?? 3, H = o.height ?? 5, y0 = o.y0 ?? 0;
  for (let i = 0; i < n; i++) {
    const a = r() * Math.PI * 2, rr = Math.sqrt(r()) * R;
    pos[i * 3] = Math.cos(a) * rr; pos[i * 3 + 1] = y0 + r() * H; pos[i * 3 + 2] = Math.sin(a) * rr;
    sp.push({ v: (o.speed ?? 0.35) * (0.4 + r()), a, rr, ph: r() * 6.28 });
  }
  const g = new T.BufferGeometry(); g.setAttribute('position', new T.BufferAttribute(pos, 3));
  const mat = new T.PointsMaterial({
    color: new T.Color(o.color ?? 0xffffff).multiplyScalar(o.k ?? 2.5), size: o.size ?? 0.07,
    map: o.petal ? petalTex() : sparkTex(), transparent: true, depthWrite: false,
    blending: o.petal ? T.NormalBlending : T.AdditiveBlending, sizeAttenuation: true, opacity: o.opacity ?? 1
  });
  const pts = new T.Points(g, mat);
  pts.userData.update = (t, dt) => {
    const p = g.attributes.position.array;
    for (let i = 0; i < n; i++) {
      const s = sp[i];
      if (o.kind === 'fall') {
        p[i * 3 + 1] -= s.v * dt; p[i * 3] += Math.sin(t * 1.3 + s.ph) * 0.004;
        if (p[i * 3 + 1] < y0) p[i * 3 + 1] = y0 + H;
      } else if (o.kind === 'orbit') {
        const a = s.a + t * s.v * 0.6; p[i * 3] = Math.cos(a) * s.rr; p[i * 3 + 2] = Math.sin(a) * s.rr;
        p[i * 3 + 1] += Math.sin(t * 2 + s.ph) * 0.002;
      } else {
        p[i * 3 + 1] += s.v * dt; p[i * 3] += Math.sin(t + s.ph) * 0.002;
        if (p[i * 3 + 1] > y0 + H) p[i * 3 + 1] = y0;
      }
    }
    g.attributes.position.needsUpdate = true;
  };
  return pts;
}
L.particles = particles;

// ---------- pedestal ----------
function pedestal(o = {}) {
  const grp = new T.Group();
  const stone = M(o.stone ?? 0x2B2840, { r: 0.85 }), stone2 = M(o.stone2 ?? 0x3A3656, { r: 0.8 });
  const sides = o.sides ?? 7;
  let g = jitter(new T.CylinderGeometry(2.25, 2.55, 0.5, sides, 1), 0.08, 31);
  put(grp, shadowy(new T.Mesh(g, stone)), 0, 0.25, 0);
  g = jitter(new T.CylinderGeometry(2.05, 2.2, 0.22, sides, 1), 0.05, 32);
  put(grp, shadowy(new T.Mesh(g, stone2)), 0, 0.61, 0);
  const rimG = new T.TorusGeometry(2.12, 0.018, 4, sides);
  const rim = put(grp, new T.Mesh(rimG, G(o.glow ?? 0x9b7bff, 1.25)), 0, 0.73, 0, Math.PI / 2, 0, 0);
  rim.rotation.z = Math.PI / sides;
  const r = rng(o.seed ?? 41);
  for (let i = 0; i < 9; i++) {
    const a = r() * Math.PI * 2, d = 2.8 + r() * 1.4, s = 0.12 + r() * 0.28;
    put(grp, blob(s, s * 0.8, s, stone, { d: 0, j: 0.2, seed: i + 5 }), Math.cos(a) * d, s * 0.4, Math.sin(a) * d, r(), r(), r());
  }
  if (o.swirl) {
    for (let i = 0; i < 4; i++) {
      const tr = new T.Mesh(new T.TorusGeometry(2.9 + i * 0.55, 0.06, 3, 48), i % 2 ? M(o.swirl2 ?? 0x1f8f8a, { r: 0.5 }) : G(o.swirl, 0.9));
      put(grp, tr, 0, 0.02, 0, Math.PI / 2, 0, 0);
    }
  }
  if (o.crystals) {
    const cm = M(o.crystals, { r: 0.2, m: 0.1, e: o.crystals, ei: 0.35 });
    for (let i = 0; i < 5; i++) {
      const a = r() * Math.PI * 2, d = 2.4 + r() * 1.0;
      const c = crystal(0.12 + r() * 0.1, 0.5 + r() * 0.7, cm, 5);
      put(grp, c, Math.cos(a) * d, 0.0, Math.sin(a) * d, (r() - 0.5) * 0.5, r() * 3, (r() - 0.5) * 0.5);
    }
  }
  const floor = new T.Mesh(new T.CircleGeometry(14, 48), M(o.floor ?? 0x120F22, { r: 1, flat: false }));
  floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; grp.add(floor);
  grp.userData.top = 0.72;
  return grp;
}
L.pedestal = pedestal;

function gradientBg(top, bottom) {
  const c = document.createElement('canvas'); c.width = 4; c.height = 256;
  const x = c.getContext('2d'); const g = x.createLinearGradient(0, 0, 0, 256);
  g.addColorStop(0, top); g.addColorStop(1, bottom); x.fillStyle = g; x.fillRect(0, 0, 4, 256);
  const t = new T.CanvasTexture(c); t.colorSpace = T.SRGBColorSpace; return t;
}

// ---------- stage (scene + camera + lights + pet) ----------
const THEMES = {
  meadow: { top: '#10261F', bottom: '#050B0C', fog: 0x07110f, stone: 0x2A3330, stone2: 0x3B4A44, floor: 0x0B1513, sky: 0xBFFFE8, dust: 0xB8FFCF },
  storm: { top: '#0E1A3D', bottom: '#04060F', fog: 0x060b1c, stone: 0x252B45, stone2: 0x353E63, floor: 0x0A0E1F, sky: 0xA9C8FF, dust: 0x9FD8FF },
  cosmic: { top: '#1A0B33', bottom: '#05020C', fog: 0x0a0418, stone: 0x2B2840, stone2: 0x3A3656, floor: 0x0D0A1A, sky: 0xD7B8FF, dust: 0xE3C6FF },
  sky: { top: '#3FA9E8', bottom: '#BDE9FF', fog: 0x9fdcff, stone: 0x6b7a8f, stone2: 0x8a99ad, floor: 0x7fc6a0, sky: 0xffffff, dust: 0xffffff }
};
L.THEMES = THEMES;

function buildStage(petId, w, h) {
  const def = L.PETS[petId];
  if (!def) throw new Error('Unknown pet ' + petId);
  const th = THEMES[def.theme] || THEMES.cosmic;
  const scene = new T.Scene();
  scene.background = gradientBg(th.top, th.bottom);
  scene.fog = new T.Fog(th.fog, 14, 34);
  scene.add(new T.HemisphereLight(th.sky, 0x080812, 0.32));
  const key = new T.DirectionalLight(0xFFF1DE, 2.7); key.position.set(4.5, 9, 6);
  key.castShadow = true; key.shadow.mapSize.set(1024, 1024);
  const sc = key.shadow.camera; sc.left = -5; sc.right = 5; sc.top = 6; sc.bottom = -3; sc.near = 1; sc.far = 25;
  key.shadow.bias = -0.0008; key.shadow.normalBias = 0.02;
  scene.add(key);
  const rim = new T.DirectionalLight(def.rim ?? def.glow, 3.2); rim.position.set(-5, 4, -6); scene.add(rim);
  const rim2 = new T.DirectionalLight(def.rim2 ?? 0x8899ff, 1.2); rim2.position.set(6, 2, -4); scene.add(rim2);
  const fill = new T.PointLight(def.glow, 2.2, 6, 1.8); fill.position.set(0, 1.2, 2.6); scene.add(fill);

  const ped = pedestal({ glow: def.glow, stone: th.stone, stone2: th.stone2, floor: th.floor, swirl: def.swirl, swirl2: def.swirl2, crystals: def.pedCrystals, seed: def.seed || 3 });
  scene.add(ped);
  const turn = new T.Group(); scene.add(turn);
  const anim = [];
  const pet = def.build({ anim, def });
  pet.position.y = ped.userData.top + (def.lift ?? 0);
  turn.add(pet);
  const dust = particles(def.dustN ?? 70, { color: def.dust ?? th.dust, radius: 5.5, height: 7, size: 0.06, speed: 0.25, k: 2.2, seed: 9 });
  scene.add(dust);
  if (def.fx) def.fx.forEach(f => { const p = particles(f.n, f); p.position.y = ped.userData.top; turn.add(p); });

  // frame camera on pet + pedestal
  turn.rotation.y = def.yaw ?? -1.0;
  turn.updateMatrixWorld(true);
  const bb = new T.Box3().setFromObject(pet);
  const size = bb.getSize(V(0, 0, 0)), ctr = bb.getCenter(V(0, 0, 0));
  const cam = new T.PerspectiveCamera(30, w / h, 0.1, 80);
  const span = Math.max(size.y * 1.32 + 0.5, (Math.max(size.x, size.z) * 1.08) / (w / h), 2.8) * (def.zoom ?? 0.9);
  const dist = span / (2 * Math.tan(T.MathUtils.degToRad(15)));
  const target = V(0, ctr.y * 0.9 + (def.camY ?? 0), 0);
  cam.position.set(0, target.y + dist * 0.16, dist);
  cam.lookAt(target);
  return { scene, cam, turn, anim, dust, scene_fx: [], baseYaw: turn.rotation.y, def };
}
L.buildStage = buildStage;

// ---------- renderer pool + cells ----------
const pools = new Map();
function pool(w, h) {
  const k = w + 'x' + h; let p = pools.get(k); if (p) return p;
  const canvas = document.createElement('canvas');
  const renderer = new T.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(1); renderer.setSize(w, h, false);
  renderer.shadowMap.enabled = true; renderer.shadowMap.type = T.PCFSoftShadowMap;
  renderer.toneMapping = T.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.0;
  renderer.outputColorSpace = T.SRGBColorSpace;
  const rt = new T.WebGLRenderTarget(w, h, { type: T.HalfFloatType, samples: 4 });
  const composer = new PP.EffectComposer(renderer, rt);
  composer.setPixelRatio(1); composer.setSize(w, h);
  const rp = new PP.RenderPass(new T.Scene(), new T.PerspectiveCamera());
  const bloom = new PP.UnrealBloomPass(new T.Vector2(w, h), 0.7, 0.45, 0.86);
  composer.addPass(rp); composer.addPass(bloom); composer.addPass(new PP.OutputPass());
  p = { renderer, composer, rp, bloom, canvas, w, h }; pools.set(k, p); return p;
}

const cells = new Set();
function mount(el) {
  if (el.__lym) return;
  const petId = el.getAttribute('data-pet');
  const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
  const cw = Math.max(64, Math.round((el.clientWidth || el.width) * dpr)), ch = Math.max(64, Math.round((el.clientHeight || el.height) * dpr));
  el.width = cw; el.height = ch;
  let stage;
  try {
    stage = el.getAttribute('data-scene') === 'flight' ? L.buildFlight(petId, cw, ch) : buildStage(petId, cw, ch);
  } catch (e) { console.error('[LYM]', e); return; }
  const cell = { petId, el, ctx: el.getContext('2d'), stage, w: cw, h: ch, visible: true, drag: 0, dragV: 0, t0: performance.now() / 1000 - Math.random() * 5 };
  el.__lym = cell; cells.add(cell);
  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver(es => es.forEach(en => { cell.visible = en.isIntersecting; }));
    io.observe(el); cell.io = io;
  }
  if (el.__lymBound) return;
  el.__lymBound = true;
  el.style.cursor = 'grab'; el.style.touchAction = 'pan-y';
  let down = false, lx = 0;
  el.addEventListener('pointerdown', e => { down = true; lx = e.clientX; el.setPointerCapture(e.pointerId); el.style.cursor = 'grabbing'; });
  el.addEventListener('pointermove', e => { if (!down) return; const dx = e.clientX - lx; lx = e.clientX; const c = el.__lym; if (c) c.drag += dx * 0.012; });
  const up = () => { down = false; el.style.cursor = 'grab'; };
  el.addEventListener('pointerup', up); el.addEventListener('pointercancel', up);
}
function scan() {
  document.querySelectorAll('canvas[data-pet]').forEach(el => {
    const c = el.__lym;
    if (c && c.petId !== el.getAttribute('data-pet')) { c.io && c.io.disconnect(); cells.delete(c); el.__lym = null; }
    mount(el);
  });
  cells.forEach(c => { if (!c.el.isConnected) { c.io && c.io.disconnect(); cells.delete(c); } });
}
let last = performance.now() / 1000;
function frame() {
  requestAnimationFrame(frame);
  if (document.hidden) return;
  const now = performance.now() / 1000, dt = Math.min(0.05, now - last); last = now;
  cells.forEach(c => {
    if (!c.visible) return;
    const s = c.stage, t = now - c.t0;
    if (s.flight) { s.update(t, dt); s.anim.forEach(f => f(t, dt)); }
    else {
      c.dragV *= 0.92; c.drag += c.dragV * 0.0;
      s.turn.rotation.y = s.baseYaw + Math.sin(t * 0.3) * 0.4 + c.drag;
      s.anim.forEach(f => f(t, dt));
      s.dust.userData.update(t, dt);
      s.turn.children.forEach(ch => ch.userData.update && ch.userData.update(t, dt));
    }
    const p = pool(c.w, c.h);
    p.rp.scene = s.scene; p.rp.camera = s.cam;
    p.bloom.strength = s.def && s.def.bloom ? s.def.bloom : 0.7;
    p.composer.render(dt);
    c.ctx.drawImage(p.canvas, 0, 0, c.w, c.h);
  });
}
L.start = function () {
  if (L._started) return; L._started = true;
  scan();
  new MutationObserver(scan).observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['data-pet'] });
  requestAnimationFrame(frame);
};
L.mount = mount;
})();
/* LAUNCH YOUR MONSTER! — reusable creature parts */
(function () {
'use strict';
const T = window.THREE, L = window.LYM;
const { V, M, G, GOLD, BONE, blob, box, aim, spike, crystal, limb, put, tube, rng } = L;

function pivot(parent, x, y, z) { const p = new T.Group(); p.position.set(x, y, z); parent.add(p); return p; }
L.pivot = pivot;

function glowEye(color, sx = 0.075, sy = 0.035, sz = 0.06) {
  const m = new T.Mesh(new T.OctahedronGeometry(1, 0), G(color, 4.5));
  m.scale.set(sx, sy, sz); return m;
}
L.glowEye = glowEye;

// Dragon / reptile head facing +Z, origin = skull center.
function dragonHead(o) {
  const g = new T.Group(), c = o.mat, c2 = o.jawMat ?? o.mat, seed = o.seed ?? 10;
  put(g, blob(0.42, 0.34, 0.44, c, { seed }), 0, 0, 0);
  put(g, blob(0.26, 0.19, 0.44, c, { seed: seed + 1 }), 0, -0.04, 0.48);
  put(g, blob(0.16, 0.07, 0.24, c, { d: 0, seed: seed + 2 }), 0.17, 0.16, 0.26, 0, 0.25, -0.4);
  put(g, blob(0.16, 0.07, 0.24, c, { d: 0, seed: seed + 3 }), -0.17, 0.16, 0.26, 0, -0.25, 0.4);
  const jaw = put(g, new T.Group(), 0, -0.2, 0.1);
  put(jaw, blob(0.22, 0.075, 0.42, c2, { seed: seed + 4 }), 0, -0.02, 0.32);
  jaw.rotation.x = o.jawOpen ?? 0.32;
  const bone = BONE();
  for (const sd of [-1, 1]) {
    for (let i = 0; i < 4; i++) {
      const tth = spike(0.028, i === 0 ? 0.16 : 0.1, bone, 4);
      put(g, tth, sd * (0.15 - i * 0.012), -0.17, 0.66 - i * 0.12, Math.PI, 0, 0);
      const lt = spike(0.024, i === 0 ? 0.12 : 0.08, bone, 4);
      put(jaw, lt, sd * 0.14, 0.03, 0.62 - i * 0.12, 0, 0, 0);
    }
    const eye = glowEye(o.eye, 0.085, 0.034, 0.07);
    put(g, eye, sd * 0.215, 0.07, 0.33, 0, sd * 0.35, sd * -0.32);
    if (o.horns !== false) {
      const hm = o.hornMat ?? bone;
      put(g, tube([V(sd * 0.2, 0.18, 0.02), V(sd * 0.34, 0.38, -0.28), V(sd * 0.4, 0.46, -0.68), V(sd * 0.33, 0.4, -1.02)],
        t => 0.1 * (1 - t) + 0.008, hm, { seg: 5, steps: 14 }));
      put(g, tube([V(sd * 0.3, 0.02, -0.1), V(sd * 0.48, 0.06, -0.36), V(sd * 0.55, 0.12, -0.6)],
        t => 0.055 * (1 - t) + 0.006, hm, { seg: 4, steps: 8 }));
    }
  }
  if (o.crest) {
    for (let i = 0; i < 5; i++) {
      const s = spike(0.05, 0.36 - i * 0.04, o.crest, 4);
      put(g, s, 0, 0.26 - i * 0.03, -0.12 - i * 0.16, -1.05 - i * 0.08, 0, 0);
    }
  }
  g.scale.setScalar(o.s ?? 1);
  g.userData.jaw = jaw;
  return g;
}
L.dragonHead = dragonHead;

// Feline / canine head facing +Z.
function beastHead(o) {
  const g = new T.Group(), c = o.mat, seed = o.seed ?? 20, snoutL = o.snout ?? 0.36;
  put(g, blob(0.4, 0.36, 0.4, c, { seed }), 0, 0, 0);
  put(g, blob(0.25, 0.2, snoutL, o.muzzle ?? c, { seed: seed + 1 }), 0, -0.1, 0.36 + (snoutL - 0.36) * 0.6);
  put(g, blob(0.09, 0.06, 0.07, M(0x14121F, { r: 0.4 }), { d: 0, seed: 3 }), 0, -0.02, 0.36 + snoutL * 0.98);
  put(g, blob(0.17, 0.07, 0.22, c, { d: 0, seed: seed + 2 }), 0.17, 0.15, 0.24, 0, 0.3, -0.45);
  put(g, blob(0.17, 0.07, 0.22, c, { d: 0, seed: seed + 3 }), -0.17, 0.15, 0.24, 0, -0.3, 0.45);
  const jaw = put(g, new T.Group(), 0, -0.24, 0.12);
  put(jaw, blob(0.2, 0.07, snoutL * 0.85, o.jawMat ?? o.muzzle ?? c, { seed: seed + 4 }), 0, -0.02, 0.24);
  jaw.rotation.x = o.jawOpen ?? 0.3;
  const bone = BONE();
  for (const sd of [-1, 1]) {
    const fang = spike(0.035, 0.2, bone, 4); put(g, fang, sd * 0.11, -0.18, 0.36 + snoutL * 0.75, Math.PI, 0, 0);
    const lf = spike(0.03, 0.14, bone, 4); put(jaw, lf, sd * 0.1, 0.02, 0.44 + (snoutL - 0.36), 0, 0, 0);
    put(g, glowEye(o.eye, 0.09, 0.036, 0.07), sd * 0.2, 0.06, 0.3, 0, sd * 0.4, sd * -0.3);
    if (o.ears !== false) {
      const em = o.earMat ?? c;
      const ear = spike(o.earR ?? 0.15, o.earH ?? 0.42, em, 4);
      put(g, ear, sd * 0.24, 0.24, -0.06, -0.35, 0, sd * -0.45);
      if (o.earInner) { const ei = spike((o.earR ?? 0.15) * 0.55, (o.earH ?? 0.42) * 0.7, o.earInner, 3); put(g, ei, sd * 0.25, 0.26, 0.0, -0.3, 0, sd * -0.45); }
      if (o.tuft) { const tf = spike(0.03, 0.22, o.tuft, 3); put(g, tf, sd * (0.24 + 0.18 * 0.9), 0.24 + 0.36, -0.06 - 0.14, -0.6, 0, sd * -0.6); }
    }
    if (o.whiskers) {
      for (let k = 0; k < 2; k++) put(g, tube([V(sd * 0.18, -0.1 - k * 0.05, 0.62), V(sd * 0.42, -0.08 - k * 0.07, 0.6), V(sd * 0.62, -0.12 - k * 0.1, 0.5)], () => 0.008, o.whiskers, { seg: 3, steps: 6 }));
    }
  }
  g.scale.setScalar(o.s ?? 1);
  g.userData.jaw = jaw;
  return g;
}
L.beastHead = beastHead;

// Quadruped body. Returns parts; head is attached by caller to parts.headPivot.
function quad(o) {
  const g = new T.Group(), c = o.mat, seed = o.seed ?? 30;
  const legH = o.legH, H = o.H, W = o.W, Lz = o.L, y = legH + H * 0.75;
  const torso = put(g, blob(W, H, Lz * 0.55, c, { seed }), 0, y, 0);
  const chest = put(g, blob(W * 1.12, H * 1.12, Lz * 0.38, c, { seed: seed + 1 }), 0, y + H * 0.15, Lz * 0.34);
  const hips = put(g, blob(W * 0.98, H, Lz * 0.33, c, { seed: seed + 2 }), 0, y + H * 0.05, -Lz * 0.36);
  if (o.belly) put(g, blob(W * 0.72, H * 0.45, Lz * 0.5, o.belly, { seed: seed + 3 }), 0, y - H * 0.55, 0.05);
  const legs = [];
  const legMat = o.legMat ?? c;
  for (const front of [true, false]) for (const sd of [-1, 1]) {
    const z = (front ? 1 : -1) * Lz * 0.38, x = sd * W * 0.7;
    const sh = V(x, y + H * 0.05, z), knee = V(x * 1.04, legH * 0.52, z + (front ? 0.06 : -0.14)), paw = V(x * 1.06, 0.12, z + (front ? 0.1 : 0.0));
    const lg = new T.Group(); g.add(lg);
    put(lg, blob(W * 0.46, H * 0.62, W * 0.55, c, { seed: seed + 5 }), sh.x, sh.y - H * 0.25, sh.z);
    lg.add(limb(sh, knee, W * 0.36, W * 0.24, legMat, 6));
    lg.add(limb(knee, paw, W * 0.24, W * 0.2, legMat, 6));
    put(lg, blob(W * 0.27, 0.11, W * 0.36, o.pawMat ?? legMat, { d: 0, seed: seed + 6 }), paw.x, 0.1, paw.z + 0.06);
    if (o.band) put(lg, new T.Mesh(new T.TorusGeometry(W * 0.25, 0.03, 4, 7), o.band), knee.x, knee.y - 0.12, knee.z, Math.PI / 2, 0, 0);
    const claw = o.clawMat ?? BONE();
    for (let k = -1; k <= 1; k++) put(lg, aim(spike(0.03, 0.15, claw, 4), V(k * 0.25, -0.35, 1)), paw.x + k * W * 0.13, 0.08, paw.z + W * 0.36);
    legs.push(lg);
  }
  const neckBase = V(0, y + H * 0.45, Lz * 0.46);
  const headPos = o.headPos ?? V(0, y + H * 1.35, Lz * 0.74);
  g.add(limb(neckBase, headPos, W * 0.62, W * 0.42, c, 7));
  const headPivot = pivot(g, headPos.x, headPos.y, headPos.z);
  const tailPivot = pivot(g, 0, y + H * 0.15, -Lz * 0.58);
  return { g, torso, chest, hips, legs, headPivot, tailPivot, y };
}
L.quad = quad;

// Bat / dragon wing extending along +X from origin.
function batWing(o) {
  const g = new T.Group(), s = o.s ?? 1, bm = o.bone;
  const elbow = V(0.7, 0.4, -0.25).multiplyScalar(s), wrist = V(1.35, 0.72, -0.15).multiplyScalar(s);
  const root = V(0.1, -0.1, -0.55).multiplyScalar(s);
  const f = [V(2.35, 1.05, -0.3), V(2.3, 0.3, -0.62), V(1.95, -0.25, -0.9), V(1.25, -0.42, -0.95)].map(v => v.multiplyScalar(s));
  g.add(limb(V(0, 0, 0), elbow, 0.09 * s, 0.065 * s, bm, 5));
  g.add(limb(elbow, wrist, 0.065 * s, 0.05 * s, bm, 5));
  f.forEach(p => g.add(limb(wrist, p, 0.045 * s, 0.012 * s, bm, 4)));
  put(g, aim(spike(0.05 * s, 0.22 * s, o.claw ?? BONE(), 4), V(0.3, 1, 0.2)), wrist.x, wrist.y, wrist.z);
  const tri = [];
  const pts = [wrist, ...f];
  for (let i = 1; i < pts.length - 1; i++) {
    const a = pts[i], b = pts[i + 1];
    const m = a.clone().lerp(b, 0.5).lerp(wrist, 0.24);
    tri.push(wrist, a, m, wrist, m, b);
  }
  const last = f[f.length - 1];
  const m2 = last.clone().lerp(root, 0.5).lerp(wrist, 0.2);
  tri.push(wrist, last, m2, wrist, m2, root, wrist, root, elbow, elbow, root, V(0, 0, 0));
  const geo = new T.BufferGeometry().setFromPoints(tri); geo.computeVertexNormals();
  const mem = new T.Mesh(geo, o.membrane); mem.castShadow = true; g.add(mem);
  if (o.side === -1) g.scale.x = -1;
  return g;
}
L.batWing = batWing;

// Feathered wing (blade feathers) extending +X.
function featherWing(o) {
  const g = new T.Group(), s = o.s ?? 1;
  const arm = [V(0, 0, 0), V(0.6, 0.3, -0.1), V(1.25, 0.45, -0.05), V(2.1, 0.35, 0.05)].map(v => v.multiplyScalar(s));
  for (let i = 0; i < 3; i++) g.add(limb(arm[i], arm[i + 1], 0.08 * s * (1 - i * 0.25), 0.06 * s * (1 - i * 0.3), o.base, 5));
  const n = o.n ?? 14, c1 = new T.Color(o.c1), c2 = new T.Color(o.c2);
  const curve = new T.CatmullRomCurve3(arm);
  for (let i = 0; i < n; i++) {
    const u = i / (n - 1);
    const p = curve.getPointAt(0.15 + u * 0.85);
    const len = (0.55 + Math.sin(u * Math.PI * 0.85) * 0.9 + u * 0.5) * s * (o.len ?? 1);
    const col = c1.clone().lerp(c2, u);
    const mat = o.glow ? M(col, { e: col, ei: (0.55 + u * 0.8) * (o.glowK ?? 1), r: 0.35 }) : M(col, { r: 0.5 });
    const geo = new T.ConeGeometry((o.fw ?? 0.15) * s, len, 4, 1); geo.translate(0, len / 2, 0); geo.scale(1, 1, 0.22);
    const fe = new T.Mesh(geo, mat); fe.castShadow = true;
    fe.position.copy(p);
    const dir = V(0.35 + u * 0.9, -0.25 - (1 - u) * 0.3, -1 + u * 0.55).normalize();
    aim(fe, dir); g.add(fe);
    if (u > 0.55 && o.tipGlow) { const tip = new T.Mesh(new T.OctahedronGeometry(0.045 * s, 0), G(o.tipGlow, 3)); tip.position.copy(p).add(dir.clone().multiplyScalar(len)); g.add(tip); }
  }
  // covert row
  for (let i = 0; i < 8; i++) {
    const u = i / 7, p = curve.getPointAt(0.05 + u * 0.75);
    const len = (0.35 + u * 0.25) * s;
    const geo = new T.ConeGeometry(0.1 * s, len, 4, 1); geo.translate(0, len / 2, 0); geo.scale(1, 1, 0.25);
    const fe = new T.Mesh(geo, o.covert ?? o.base); fe.position.copy(p).add(V(0, 0.02, 0));
    aim(fe, V(0.3 + u * 0.4, -0.15, -1)); g.add(fe);
  }
  if (o.side === -1) g.scale.x = -1;
  return g;
}
L.featherWing = featherWing;

// Tail along points, with optional tip object; returns mesh.
function tail(pts, r0, mat, o = {}) {
  return tube(pts, t => r0 * Math.pow(1 - t, o.pow ?? 0.85) + (o.rEnd ?? 0.015), mat, { seg: o.seg ?? 6, steps: o.steps ?? 30, colorFn: o.colorFn });
}
L.tail = tail;

// Row of spikes along a curve (local space of parent)
function spikeRow(parent, curve, n, mat, o = {}) {
  for (let i = 0; i < n; i++) {
    const u = (o.from ?? 0.05) + i / Math.max(1, n - 1) * ((o.to ?? 0.95) - (o.from ?? 0.05));
    const p = curve.getPointAt(u), tg = curve.getTangentAt(u);
    const up = o.up ?? V(0, 1, 0);
    const h = (o.h ?? 0.3) * (o.hFn ? o.hFn(u) : 1);
    const s = (o.crystal ? crystal((o.r ?? 0.07) * 1.4, h * 1.2, mat, 5) : spike(o.r ?? 0.07, h, mat, o.seg ?? 4));
    s.position.copy(p).add(up.clone().multiplyScalar(o.off ?? 0.1));
    aim(s, up.clone().multiplyScalar(1).add(tg.clone().multiplyScalar(-(o.back ?? 0.8))));
    parent.add(s);
  }
}
L.spikeRow = spikeRow;

// Mane: cone spikes radiating from a center, biased backwards
function mane(parent, center, o) {
  const r = rng(o.seed ?? 51), grp = new T.Group(); grp.position.copy(center); parent.add(grp);
  const cols = o.colors.map(c => new T.Color(c));
  for (let i = 0; i < (o.n ?? 40); i++) {
    const a = r() * Math.PI * 2, el = (r() - 0.25) * 1.3;
    const dir = V(Math.cos(a) * Math.cos(el), Math.sin(el) * 0.8 + (o.lift ?? 0.12), Math.sin(a) * Math.cos(el) * 0.55 - (o.backBias ?? 0.9)).normalize();
    if (dir.z > (o.maxZ ?? 0.35)) continue;
    const ci = cols[Math.floor(r() * cols.length)];
    const mat = M(ci, { r: 0.3, e: ci, ei: o.ei ?? 0.45 });
    const h = (o.h ?? 0.8) * (0.55 + r() * 0.75), rad = (o.r ?? 0.11) * (0.6 + r() * 0.6);
    const s = spike(rad, h, mat, 4);
    s.position.copy(dir.clone().multiplyScalar(o.base ?? 0.35));
    aim(s, dir); grp.add(s);
  }
  return grp;
}
L.mane = mane;

// Serpent body as tube along pts; up = world up frames; belly colour on bottom.
function serpentBody(pts, rFn, cTop, cBelly, o = {}) {
  const top = new T.Color(cTop), bel = new T.Color(cBelly), stripe = o.stripe ? new T.Color(o.stripe) : null;
  const mat = M(0xffffff, { vc: true, r: 0.5 });
  const m = tube(pts, rFn, mat, {
    seg: o.seg ?? 7, steps: o.steps ?? 140, up: V(0, 1, 0),
    colorFn: (t, d) => {
      const k = Math.max(0, Math.min(1, (-d.y + 0.15) * 1.6));
      const c = top.clone().lerp(bel, k);
      if (stripe && Math.floor(t * (o.stripes ?? 22)) % 2 === 0 && d.y > 0.2) c.lerp(stripe, 0.45);
      return c;
    }
  });
  return m;
}
L.serpentBody = serpentBody;

// Band (torus) around a curve point
function band(parent, curve, u, rad, mat, o = {}) {
  const p = curve.getPointAt(u), tg = curve.getTangentAt(u);
  const tr = new T.Mesh(new T.TorusGeometry(rad, o.th ?? 0.045, 4, o.seg ?? 8), mat);
  tr.position.copy(p); tr.lookAt(p.clone().add(tg)); tr.castShadow = true; parent.add(tr);
  return tr;
}
L.band = band;

// Glow ring (halo)
function halo(r, color, th = 0.04, seg = 40) {
  return new T.Mesh(new T.TorusGeometry(r, th, 4, seg), G(color, 3));
}
L.halo = halo;
})();
/* LAUNCH YOUR MONSTER! — the 16 monsters */
(function () {
'use strict';
const T = window.THREE, L = window.LYM;
const { V, M, G, GOLD, BONE, blob, box, aim, spike, crystal, limb, put, tube, cracks, rng, pivot,
  glowEye, dragonHead, beastHead, quad, batWing, featherWing, tail, spikeRow, mane, serpentBody, band, halo } = L;
const P = (L.PETS = {});

// shared animation helpers
function breathe(anim, obj, k = 0.025, sp = 2) { const s0 = obj.scale.clone(); anim.push(t => obj.scale.set(s0.x * (1 + Math.sin(t * sp) * k * 0.6), s0.y * (1 + Math.sin(t * sp) * k), s0.z)); }
function sway(anim, obj, axis, amp, sp, ph = 0) { const b = obj.rotation[axis]; anim.push(t => { obj.rotation[axis] = b + Math.sin(t * sp + ph) * amp; }); }
function bob(anim, obj, amp, sp, ph = 0) { const b = obj.position.y; anim.push(t => { obj.position.y = b + Math.sin(t * sp + ph) * amp; }); }
function spin(anim, obj, sp) { anim.push((t, dt) => { obj.rotation.y += sp * dt; }); }
function flicker(anim, mat, base, amp, sp) { const c0 = mat.color.clone(); anim.push(t => { const k = 1 + Math.sin(t * sp) * amp + Math.sin(t * sp * 2.7) * amp * 0.5; mat.color.copy(c0).multiplyScalar(k); }); }

/* ============ STARTER + MEADOW EGG ============ */

// 1. MALLOW — sky-dragon whelp: storm-blue scales, ice-crystal spine, glowing cyan core
P.mallow = {
  name: 'Mallow', theme: 'meadow', glow: 0x47E5FF, rim: 0x5FD0FF, yaw: -0.6, seed: 4,
  fx: [{ n: 26, kind: 'rise', color: 0x8FF3FF, radius: 1.6, height: 3, size: 0.06, speed: 0.4 }],
  build({ anim }) {
    const root = new T.Group();
    const skin = M(0x3E86D6, { r: 0.55 }), belly = M(0xCFE9FF, { r: 0.5 }), dark = M(0x274F95, { r: 0.6 });
    const ice = M(0xBFF6FF, { r: 0.15, m: 0.1, e: 0x47E5FF, ei: 0.55 });
    const glow = G(0x47E5FF, 2.2);
    const q = quad({ mat: skin, belly, legH: 0.55, H: 0.48, W: 0.48, L: 1.7, seed: 4, legMat: dark, clawMat: BONE() });
    root.add(q.g);
    const head = dragonHead({ mat: skin, jawMat: dark, eye: 0x7FF6FF, s: 0.95, hornMat: M(0xF1E6C8, { r: 0.4 }), crest: ice, seed: 12 });
    q.headPivot.add(head); q.headPivot.rotation.set(-0.1, 0.18, 0);
    sway(anim, q.headPivot, 'y', 0.12, 0.7); sway(anim, q.headPivot, 'x', 0.05, 1.1);
    sway(anim, head.userData.jaw, 'x', 0.08, 1.4);
    const core = put(q.g, new T.Mesh(new T.OctahedronGeometry(0.17, 0), glow), 0, q.y + 0.1, 1.0);
    core.scale.set(1, 1.3, 0.5); flicker(anim, glow, 1, 0.12, 3);
    cracks(q.chest, 7, glow, { seed: 5, w: 0.02, yMin: -0.3, yMax: 0.8 });
    cracks(q.torso, 6, glow, { seed: 6, w: 0.018 });
    const spine = new T.CatmullRomCurve3([V(0, q.y + 0.62, 0.65), V(0, q.y + 0.52, 0), V(0, q.y + 0.42, -0.7)]);
    spikeRow(q.g, spine, 6, ice, { h: 0.42, r: 0.09, back: 0.5, off: -0.02, crystal: true, hFn: u => 1.1 - u * 0.5 });
    const tl = tail([V(0, 0, 0), V(0, 0.1, -0.7), V(0.35, 0.05, -1.4), V(0.9, 0.25, -1.9), V(1.4, 0.55, -2.0)], 0.3, skin, { pow: 0.9 });
    q.tailPivot.add(tl); spikeRow(q.tailPivot, tl.userData.curve, 6, ice, { h: 0.26, r: 0.06, off: 0.02, from: 0.1, to: 0.8, hFn: u => 1 - u * 0.6 });
    put(q.tailPivot, crystal(0.13, 0.55, ice, 5), 1.4, 0.55, -2.0, 0, 0, -1.2);
    sway(anim, q.tailPivot, 'y', 0.22, 1.3);
    const mem = M(0x7FE3FF, { r: 0.3, e: 0x2BB8FF, ei: 0.35, op: 0.78, dw: false });
    for (const sd of [-1, 1]) {
      const wp = pivot(q.g, sd * 0.38, q.y + 0.5, 0.35);
      wp.add(batWing({ bone: dark, membrane: mem, s: 0.85, side: sd }));
      wp.rotation.set(0, sd * 0.35, sd * 0.55);
      sway(anim, wp, 'z', 0.18 * sd, 2.2);
    }
    breathe(anim, q.chest, 0.03, 2.2);
    return root;
  }
};

// 11. AURORA LYNX — hero crystal lynx: faceted teal/violet body, aurora cracks, crystal mane
P.auroraLynx = {
  name: 'Aurora Lynx', theme: 'storm', glow: 0x6CF2FF, rim: 0xB070FF, rim2: 0x3DE0D0, seed: 7, pedCrystals: 0x9B6BFF,
  fx: [{ n: 40, kind: 'rise', color: 0xC9A2FF, radius: 2, height: 4, size: 0.07, speed: 0.5 }],
  build({ anim }) {
    const root = new T.Group();
    const skin = M(0x5546A8, { r: 0.45, m: 0.15 }), dark = M(0x2E2766, { r: 0.55 }), muzzle = M(0x7C6CD0, { r: 0.45 });
    const glow = G(0x7DF4FF, 2.2), glow2 = G(0xD48CFF, 2.0);
    const q = quad({ mat: skin, legH: 0.85, H: 0.62, W: 0.62, L: 2.4, seed: 70, legMat: skin, pawMat: dark });
    root.add(q.g);
    const head = beastHead({ mat: skin, muzzle, jawMat: dark, eye: 0xE9FFFF, s: 1.15, earH: 0.5, earR: 0.16, earInner: G(0xC07BFF, 1.6), tuft: glow2, jawOpen: 0.42, seed: 71 });
    q.headPivot.add(head); q.headPivot.rotation.set(-0.12, 0.2, 0);
    sway(anim, q.headPivot, 'y', 0.1, 0.6); sway(anim, head.userData.jaw, 'x', 0.1, 1.2);
    mane(q.headPivot, V(0, 0.1, -0.32), { colors: [0x8E5BFF, 0xB98BFF, 0x5BE3F2, 0x7B49E8], n: 90, h: 1.1, r: 0.13, base: 0.34, ei: 0.4, seed: 72, maxZ: -0.12 });
    mane(q.g, V(0, q.y + 0.6, 0.55), { colors: [0x6E43D8, 0x9A6BFF, 0x4CCFE6], n: 34, h: 0.75, r: 0.12, base: 0.45, ei: 0.35, seed: 73 });
    [q.chest, q.torso, q.hips].forEach((b, i) => cracks(b, 7, i % 2 ? glow2 : glow, { seed: 80 + i, w: 0.026 }));
    q.legs.forEach((lg, i) => lg.children.slice(0, 1).forEach(b => cracks(b, 3, glow, { seed: 90 + i, w: 0.02 })));
    const tl = tail([V(0, 0, 0), V(0, 0.3, -0.6), V(0.1, 0.9, -1.0), V(0.0, 1.4, -0.95)], 0.24, skin, { pow: 0.7 });
    q.tailPivot.add(tl);
    const tip = put(q.tailPivot, crystal(0.16, 0.7, M(0xC9A2FF, { r: 0.2, e: 0xA36BFF, ei: 0.8 }), 5), 0.0, 1.38, -0.95, 0.2, 0, 0);
    sway(anim, q.tailPivot, 'z', 0.12, 1.1);
    breathe(anim, q.chest, 0.025, 1.8);
    return root;
  }
};

// 8. CLOUD SERPENT — coiled sky dragon, gold bands, cloud fins, teal swirl pedestal
P.cloudSerpent = {
  name: 'Cloud Serpent', theme: 'storm', glow: 0x5BF0E6, rim: 0x5BD8FF, yaw: -0.4, seed: 8, swirl: 0x2EE6D6, swirl2: 0x0F6E70,
  fx: [{ n: 30, kind: 'orbit', color: 0x9FFFF5, radius: 2.4, height: 3.5, size: 0.08, speed: 0.6 }],
  build({ anim }) {
    const root = new T.Group();
    const pts = [];
    for (let i = 0; i <= 26; i++) {
      const u = i / 26, a = u * Math.PI * 4.2, r = 1.55 - u * 0.75;
      pts.push(V(Math.cos(a) * r, 0.32 + u * 1.1 + Math.sin(a * 2) * 0.05, Math.sin(a) * r));
    }
    const last = pts[pts.length - 1];
    pts.push(last.clone().add(V(0.15, 0.7, 0.35)), last.clone().add(V(0.1, 1.5, 0.9)), last.clone().add(V(0, 2.1, 1.25)));
    const body = serpentBody(pts, t => 0.04 + Math.sin(Math.min(1, t * 1.25) * Math.PI * 0.62) * 0.36 - (t > 0.85 ? (t - 0.85) * 0.6 : 0), 0x1C8C9C, 0x9FF3E6, { stripe: 0x0E5A6A, stripes: 30 });
    root.add(body);
    const curve = body.userData.curve;
    const gold = GOLD();
    for (let i = 1; i < 12; i++) { const u = 0.12 + i * 0.07; if (u > 0.94) break; band(root, curve, u, 0.36 * Math.sin(Math.min(1, u * 1.25) * Math.PI * 0.62) + 0.06, gold, { th: 0.05 }); }
    const fin = M(0xE9FBFF, { r: 0.4, e: 0x8FFFF2, ei: 0.15 });
    spikeRow(root, curve, 22, M(0x0F5B66, { r: 0.4 }), { h: 0.36, r: 0.06, off: 0.22, from: 0.1, to: 0.93, back: 1.1, hFn: u => 0.4 + Math.sin(u * Math.PI) * 0.8 });
    const r = rng(81);
    for (let i = 0; i < 9; i++) {
      const u = 0.14 + i * 0.09, p = curve.getPointAt(u);
      const cl = new T.Group(); cl.position.copy(p).add(V(0, 0.32, 0));
      for (let k = 0; k < 4; k++) put(cl, blob(0.14 + r() * 0.1, 0.1 + r() * 0.06, 0.14 + r() * 0.1, fin, { d: 0, seed: i * 7 + k }), (r() - 0.5) * 0.35, r() * 0.12, (r() - 0.5) * 0.35);
      root.add(cl);
    }
    const hp = pivot(root, 0, 0, 0);
    const end = curve.getPointAt(1), tg = curve.getTangentAt(0.985);
    hp.position.copy(end);
    const head = dragonHead({ mat: M(0x1C8C9C, { r: 0.5 }), jawMat: M(0x0F5B66, { r: 0.5 }), eye: 0xFFF2A8, s: 0.95, hornMat: gold, crest: M(0x0F5B66, { r: 0.4 }), jawOpen: 0.45, seed: 82 });
    const hg = new T.Group(); hg.add(head); hp.add(hg);
    hg.lookAt(hp.position.clone().add(V(tg.x * 0.4 + 0.3, 0, tg.z * 0.4 + 1)));
    hg.rotation.x += 0.25;
    const whisk = M(0xFFE58A, { r: 0.4, e: 0xFFC94A, ei: 0.4 });
    for (const sd of [-1, 1]) head.add(tube([V(sd * 0.2, -0.05, 0.75), V(sd * 0.55, 0.0, 0.8), V(sd * 0.85, -0.25, 0.55), V(sd * 1.05, -0.55, 0.25)], t => 0.03 * (1 - t) + 0.006, whisk, { seg: 4, steps: 14 }));
    sway(anim, hp, 'y', 0.1, 0.8); bob(anim, hp, 0.04, 1.6);
    return root;
  }
};
})();
/* LAUNCH YOUR MONSTER! — monsters, part 2 */
(function () {
'use strict';
const T = window.THREE, L = window.LYM;
const { V, M, G, GOLD, BONE, blob, box, aim, spike, crystal, limb, put, tube, cracks, rng, pivot,
  glowEye, dragonHead, beastHead, quad, batWing, featherWing, tail, spikeRow, mane, serpentBody, band, halo } = L;
const P = L.PETS;
function breathe(anim, obj, k = 0.025, sp = 2) { const s0 = obj.scale.clone(); anim.push(t => obj.scale.set(s0.x * (1 + Math.sin(t * sp) * k * 0.6), s0.y * (1 + Math.sin(t * sp) * k), s0.z)); }
function sway(anim, obj, axis, amp, sp, ph = 0) { const b = obj.rotation[axis]; anim.push(t => { obj.rotation[axis] = b + Math.sin(t * sp + ph) * amp; }); }
function bob(anim, obj, amp, sp, ph = 0) { const b = obj.position.y; anim.push(t => { obj.position.y = b + Math.sin(t * sp + ph) * amp; }); }
function flicker(anim, mat, amp, sp) { const c0 = mat.color.clone(); anim.push(t => { const k = 1 + Math.sin(t * sp) * amp + Math.sin(t * sp * 2.7) * amp * 0.5; mat.color.copy(c0).multiplyScalar(k); }); }
const vc = (a, b) => { const A = new T.Color(a), B = new T.Color(b); return (t) => A.clone().lerp(B, t); };

// 2. PUDDLE PUP — tidal wolf with fin ears and orbiting water orbs
P.puddlePup = {
  name: 'Puddle Pup', theme: 'meadow', glow: 0x3FF0E0, rim: 0x3FE0FF, seed: 12,
  fx: [{ n: 30, kind: 'rise', color: 0xAFFFF8, radius: 1.8, height: 3, size: 0.08, speed: 0.35 }],
  build({ anim }) {
    const root = new T.Group();
    const skin = M(0x1E9E98, { r: 0.45 }), dark = M(0x0E5C63, { r: 0.5 }), belly = M(0xA6F2E8, { r: 0.5 });
    const fin = M(0x7FFFF0, { r: 0.2, e: 0x2FE0D0, ei: 0.45, op: 0.82, dw: false });
    const glow = G(0x5FFFF0, 2.0);
    const q = quad({ mat: skin, belly, legH: 0.6, H: 0.5, W: 0.5, L: 1.9, seed: 120, legMat: dark });
    root.add(q.g);
    const head = beastHead({ mat: skin, muzzle: M(0xBDF7EE, { r: 0.5 }), jawMat: dark, eye: 0xCFFFFF, snout: 0.5, earMat: fin, earH: 0.55, earR: 0.2, s: 1.0, jawOpen: 0.25, seed: 121 });
    q.headPivot.add(head); q.headPivot.rotation.set(-0.05, 0.2, 0);
    sway(anim, q.headPivot, 'y', 0.12, 0.8);
    const spine = new T.CatmullRomCurve3([V(0, q.y + 0.6, 0.75), V(0, q.y + 0.52, 0), V(0, q.y + 0.45, -0.75)]);
    spikeRow(q.g, spine, 7, fin, { h: 0.5, r: 0.13, back: 1.2, off: -0.05, hFn: u => 1 - Math.abs(u - 0.35) });
    cracks(q.torso, 5, glow, { seed: 122, w: 0.018 });
    cracks(q.chest, 4, glow, { seed: 123, w: 0.018 });
    const tl = tail([V(0, 0, 0), V(0, 0.15, -0.6), V(0, 0.35, -1.2), V(0, 0.5, -1.55)], 0.25, skin);
    q.tailPivot.add(tl);
    for (const sd of [-1, 1]) put(q.tailPivot, blob(0.5, 0.06, 0.28, fin, { d: 1, seed: 125 + sd }), sd * 0.38, 0.55, -1.65, 0, sd * 0.6, sd * 0.25);
    sway(anim, q.tailPivot, 'y', 0.3, 1.6);
    const orbs = pivot(root, 0, q.y + 0.4, 0);
    const water = new T.MeshStandardMaterial({ color: 0x9FFFF8, roughness: 0.05, metalness: 0.1, transparent: true, opacity: 0.45, depthWrite: false });
    for (let i = 0; i < 4; i++) {
      const a = i / 4 * Math.PI * 2, o = new T.Group();
      o.add(new T.Mesh(new T.IcosahedronGeometry(0.2, 2), water));
      o.add(new T.Mesh(new T.OctahedronGeometry(0.07, 0), G(0x7FFFF5, 3)));
      o.position.set(Math.cos(a) * 1.35, Math.sin(a * 2) * 0.25, Math.sin(a) * 1.35);
      orbs.add(o);
    }
    anim.push((t, dt) => { orbs.rotation.y += dt * 0.8; });
    breathe(anim, q.chest, 0.025, 2.0);
    return root;
  }
};

// 3. AERO KITTY — gale cat with blade-feather wings and gold bands
P.aeroKitty = {
  name: 'Aero Kitty', theme: 'meadow', glow: 0xFFB347, rim: 0xFFC27A, rim2: 0xFF8A3D, seed: 13,
  fx: [{ n: 26, kind: 'rise', color: 0xFFE2A8, radius: 2, height: 3.5, size: 0.06, speed: 0.6 }],
  build({ anim }) {
    const root = new T.Group();
    const skin = M(0xD9772E, { r: 0.5 }), dark = M(0x7A3410, { r: 0.55 }), belly = M(0xFFE2B8, { r: 0.5 }), gold = GOLD();
    const q = quad({ mat: skin, belly, legH: 0.75, H: 0.48, W: 0.46, L: 1.9, seed: 130, legMat: skin, pawMat: belly, band: gold });
    root.add(q.g);
    const head = beastHead({ mat: skin, muzzle: belly, jawMat: dark, eye: 0xB6FF6A, snout: 0.3, earH: 0.55, earR: 0.17, earInner: belly, tuft: G(0xFFE2A8, 1.4), whiskers: gold, jawOpen: 0.22, s: 1.0, seed: 131 });
    q.headPivot.add(head); q.headPivot.rotation.set(-0.08, 0.25, 0);
    sway(anim, q.headPivot, 'y', 0.12, 0.7);
    put(q.g, new T.Mesh(new T.TorusGeometry(0.38, 0.06, 5, 9), gold), 0, q.y + 0.55, 0.92, 1.1, 0, 0);
    put(q.g, crystal(0.09, 0.3, M(0xFFD27A, { e: 0xFFB347, ei: 0.9, r: 0.2 }), 5), 0, q.y + 0.22, 1.24, 2.3, 0, 0);
    for (const sd of [-1, 1]) {
      const wp = pivot(q.g, sd * 0.32, q.y + 0.4, 0.3);
      wp.add(featherWing({ base: belly, covert: M(0xF5C58A, { r: 0.5 }), c1: 0xFFE2B0, c2: 0xFF6A12, tipGlow: 0xFFC65A, glow: true, glowK: 0.5, s: 0.85, side: sd, n: 13 }));
      wp.rotation.set(0.15, sd * 0.25, sd * 0.75);
      sway(anim, wp, 'z', 0.15 * sd, 2.4);
    }
    const tl = tail([V(0, 0, 0), V(0, 0.4, -0.5), V(0.15, 1.0, -0.8), V(0.45, 1.35, -0.6)], 0.15, skin, { pow: 0.5 });
    q.tailPivot.add(tl);
    for (let k = -1; k <= 1; k++) { const f = spike(0.08, 0.5, M(0xFFF1D6, { e: 0xFFB347, ei: 0.3 }), 4); f.scale.z = 0.3; put(q.tailPivot, f, 0.45, 1.35, -0.6, 0.3, 0, -0.9 + k * 0.4); }
    sway(anim, q.tailPivot, 'z', 0.15, 1.3);
    breathe(anim, q.chest, 0.025, 2.0);
    return root;
  }
};

// 4. LEAF GECKO — voxel moss lizard with glowing leaf crystals and gold bands
P.leafGecko = {
  name: 'Leaf Gecko', theme: 'meadow', glow: 0x9CFF57, rim: 0xB4FF7A, rim2: 0x3DE09A, seed: 14,
  fx: [{ n: 24, kind: 'rise', color: 0xC8FF8A, radius: 2, height: 3, size: 0.07, speed: 0.3 }],
  build({ anim }) {
    const root = new T.Group();
    const bark = M(0x6B4A2B, { r: 0.8 }), barkD = M(0x4A321C, { r: 0.85 }), moss = M(0x4E9A3A, { r: 0.75 }), moss2 = M(0x6CBF45, { r: 0.7 });
    const gold = GOLD(), leaf = M(0x9CFF57, { e: 0x6CFF3A, ei: 0.75, r: 0.3 }), vine = M(0x2F6B2A, { r: 0.8 }), gem = G(0x3DF0D0, 2.2);
    const g = new T.Group(); root.add(g);
    const y = 0.75;
    put(g, box(1.0, 0.55, 1.1, bark), 0, y, 0.45);
    put(g, box(1.05, 0.25, 1.15, moss), 0, y + 0.36, 0.45);
    put(g, box(0.9, 0.5, 1.0, bark), 0, y - 0.03, -0.55);
    put(g, box(0.95, 0.22, 1.05, moss), 0, y + 0.3, -0.55);
    for (const z of [0.45, -0.55]) for (const sd of [-1, 1]) {
      put(g, box(0.06, 0.28, 0.9, vine), sd * 0.53, y - 0.05, z);
      for (let k = 0; k < 3; k++) put(g, box(0.07, 0.07, 0.07, gem), sd * 0.56, y - 0.12 + (k % 2) * 0.12, z - 0.3 + k * 0.3);
    }
    const hp = pivot(g, 0, y + 0.15, 1.25);
    put(hp, box(0.86, 0.52, 0.7, bark), 0, 0.02, 0.1);
    put(hp, box(0.9, 0.18, 0.74, moss2), 0, 0.34, 0.1);
    put(hp, box(0.66, 0.24, 0.62, barkD), 0, 0.02, 0.72);
    const jw = pivot(hp, 0, -0.18, 0.4); put(jw, box(0.6, 0.14, 0.62, barkD), 0, 0, 0.3); jw.rotation.x = 0.28;
    for (let k = 0; k < 4; k++) for (const sd of [-1, 1]) { put(hp, box(0.06, 0.12, 0.06, BONE()), sd * 0.26, -0.14, 0.5 + k * 0.12); put(jw, box(0.05, 0.1, 0.05, BONE()), sd * 0.24, 0.1, 0.12 + k * 0.12); }
    put(hp, box(0.92, 0.08, 0.1, gold), 0, 0.2, 0.46);
    for (const sd of [-1, 1]) {
      put(hp, box(0.14, 0.1, 0.12, G(0xFFE45C, 3.5)), sd * 0.4, 0.14, 0.38);
      put(hp, box(0.06, 0.5, 0.32, leaf), sd * 0.3, 0.55, -0.15, -0.6, 0, sd * -0.35);
    }
    put(hp, box(0.06, 0.62, 0.36, leaf), 0, 0.6, -0.2, -0.7, 0, 0);
    sway(anim, jw, 'x', 0.08, 1.3);
    sway(anim, hp, 'y', 0.12, 0.8); sway(anim, hp, 'x', 0.04, 1.2);
    for (const [z, fr] of [[0.75, 1], [-0.75, -1]]) for (const sd of [-1, 1]) {
      const lg = pivot(g, sd * 0.5, y - 0.1, z);
      put(lg, box(0.5, 0.24, 0.26, bark), sd * 0.3, 0, 0);
      put(lg, box(0.24, 0.6, 0.26, barkD), sd * 0.55, -0.32, 0.03 * fr);
      put(lg, box(0.28, 0.08, 0.3, gold), sd * 0.55, -0.42, 0.03 * fr);
      put(lg, box(0.34, 0.12, 0.4, moss), sd * 0.6, -0.62, 0.08);
    }
    const tp = pivot(g, 0, y, -1.05);
    let px = 0, pz = 0, ang = 0;
    for (let i = 0; i < 7; i++) {
      const s = 1 - i * 0.12; ang += 0.22;
      put(tp, box(0.5 * s, 0.38 * s, 0.42, bark), px, -i * 0.02, pz, 0, ang, 0);
      put(tp, box(0.54 * s, 0.14 * s, 0.44, moss), px, 0.22 * s - i * 0.02, pz, 0, ang, 0);
      px -= Math.sin(ang) * 0.4; pz -= Math.cos(ang) * 0.4;
    }
    sway(anim, tp, 'y', 0.18, 1.2);
    const r = rng(141);
    for (let i = 0; i < 9; i++) {
      const c = crystal(0.08 + r() * 0.06, 0.35 + r() * 0.45, leaf, 4);
      put(g, c, (r() - 0.5) * 0.8, y + 0.47, -0.95 + r() * 1.8, (r() - 0.5) * 0.6, r() * 3, (r() - 0.5) * 0.6);
    }
    for (let i = 0; i < 6; i++) put(g, box(0.18, 0.04, 0.3, moss2), (r() - 0.5) * 0.9, y + 0.5, -0.9 + r() * 1.7, 0.4, r() * 3, 0.3);
    return root;
  }
};

// 5. EMBER CHICK — lava-cracked phoenix hatchling with a flame crest
P.emberChick = {
  name: 'Ember Chick', theme: 'meadow', glow: 0xFF7A2B, rim: 0xFF6A2B, rim2: 0xFFB347, seed: 15, bloom: 0.85,
  fx: [{ n: 60, kind: 'rise', color: 0xFF9A3D, radius: 1.4, height: 4, size: 0.07, speed: 0.9, k: 3 }],
  build({ anim }) {
    const root = new T.Group();
    const char = M(0x2B1D1B, { r: 0.7 }), char2 = M(0x4A1E16, { r: 0.65 }), gold = GOLD();
    const lava = G(0xFF6A1F, 2.6), lava2 = G(0xFFB13D, 2.4);
    const g = new T.Group(); root.add(g);
    for (const sd of [-1, 1]) {
      g.add(limb(V(sd * 0.3, 1.0, 0), V(sd * 0.34, 0.45, 0.15), 0.12, 0.07, gold, 5));
      g.add(limb(V(sd * 0.34, 0.45, 0.15), V(sd * 0.36, 0.08, 0.05), 0.07, 0.05, gold, 5));
      for (let k = -1; k <= 1; k++) put(g, aim(spike(0.035, 0.28, BONE(), 4), V(k * 0.4, -0.15, 1)), sd * 0.36, 0.06, 0.08);
    }
    const body = put(g, blob(0.78, 0.82, 0.8, char, { seed: 151 }), 0, 1.45, 0);
    const chest = put(g, blob(0.55, 0.6, 0.4, char2, { seed: 152 }), 0, 1.35, 0.42);
    const hp = pivot(g, 0, 2.25, 0.25);
    const head = put(hp, blob(0.46, 0.44, 0.46, char, { seed: 153 }), 0, 0, 0);
    put(hp, aim(spike(0.13, 0.42, gold, 4), V(0, -0.35, 1)), 0, -0.02, 0.38);
    put(hp, aim(spike(0.09, 0.22, M(0xB07A1E, { m: 0.6, r: 0.4 }), 4), V(0, -0.8, 1)), 0, -0.13, 0.36);
    for (const sd of [-1, 1]) put(hp, glowEye(0xFFE27A, 0.09, 0.04, 0.06), sd * 0.24, 0.07, 0.36, 0, sd * 0.4, sd * -0.35);
    const crestM = [G(0xFF4A12, 2.2), G(0xFF8A1F, 2.4), G(0xFFC23D, 2.6)];
    for (let i = 0; i < 7; i++) {
      const a = (i - 3) * 0.22;
      const c = tube([V(Math.sin(a) * 0.2, 0.3, 0.1), V(Math.sin(a) * 0.35, 0.75, -0.1), V(Math.sin(a) * 0.45, 1.0, -0.55)], t => 0.09 * (1 - t) + 0.01, crestM[i % 3], { seg: 4, steps: 10 });
      hp.add(c);
    }
    sway(anim, hp, 'y', 0.15, 0.9); sway(anim, hp, 'x', 0.05, 1.5);
    cracks(body, 12, lava, { seed: 155, w: 0.024 });
    cracks(chest, 6, lava2, { seed: 156, w: 0.02 });
    cracks(head, 5, lava, { seed: 157, w: 0.018, yMin: -0.5, yMax: 0.5 });
    flicker(anim, lava, 0.15, 5); flicker(anim, crestM[2], 0.2, 7);
    for (const sd of [-1, 1]) {
      const wp = pivot(g, sd * 0.6, 1.75, -0.05);
      wp.add(featherWing({ base: char, covert: char2, c1: 0x3A2420, c2: 0xFF5A12, tipGlow: 0xFFC34A, glow: true, s: 0.72, side: sd, n: 11 }));
      wp.rotation.set(0.1, sd * 0.4, sd * 0.55);
      sway(anim, wp, 'z', 0.2 * sd, 2.6);
    }
    for (let i = 0; i < 4; i++) {
      const a = (i - 1.5) * 0.3;
      g.add(tube([V(0, 1.2, -0.6), V(Math.sin(a) * 0.5, 0.95, -1.2), V(Math.sin(a) * 0.9, 0.7, -1.7)], t => 0.1 * (1 - t) + 0.01, crestM[i % 3], { seg: 4, steps: 12 }));
    }
    breathe(anim, body, 0.03, 2.4);
    return root;
  }
};

// 6. STAR BUNNY — voxel celestial hare with star-blossom branches and a halo
P.starBunny = {
  name: 'Star Bunny', theme: 'meadow', glow: 0xFF9FD6, rim: 0xFFB8E6, rim2: 0xFFE27A, seed: 16,
  fx: [{ n: 70, kind: 'fall', petal: true, color: 0xFF8FC8, radius: 2.4, height: 4.5, size: 0.13, speed: 0.35, k: 1.4, y0: 0 }],
  build({ anim }) {
    const root = new T.Group();
    const white = M(0xF2F1F6, { r: 0.6 }), grey = M(0xC9C6D6, { r: 0.65 }), pink = M(0xFF8FC8, { e: 0xFF5FAE, ei: 0.35, r: 0.5 }), gold = GOLD();
    const branch = M(0xE6E2EE, { r: 0.6 });
    const g = new T.Group(); root.add(g);
    put(g, box(0.9, 0.8, 1.0, white), 0, 1.0, -0.35);
    put(g, box(0.8, 0.75, 0.7, white), 0, 1.15, 0.35, -0.2, 0, 0);
    put(g, box(0.6, 0.3, 0.6, grey), 0, 0.7, 0.4);
    for (const sd of [-1, 1]) {
      put(g, box(0.32, 0.7, 0.7, white), sd * 0.45, 0.6, -0.45);
      put(g, box(0.28, 0.12, 0.7, grey), sd * 0.45, 0.06, -0.25);
      put(g, box(0.2, 0.75, 0.22, white), sd * 0.25, 0.45, 0.55);
      put(g, box(0.24, 0.1, 0.32, grey), sd * 0.25, 0.06, 0.62);
    }
    const tailStar = new T.Mesh(new T.OctahedronGeometry(0.22, 0), G(0xFFE27A, 2.6));
    put(g, tailStar, 0, 1.15, -0.95);
    anim.push((t, dt) => { tailStar.rotation.y += dt * 1.5; });
    const hp = pivot(g, 0, 1.75, 0.6);
    put(hp, box(0.62, 0.55, 0.62, white), 0, 0, 0);
    put(hp, box(0.4, 0.3, 0.3, white), 0, -0.1, 0.38);
    put(hp, box(0.12, 0.08, 0.06, M(0xFF8FB0, { r: 0.5 })), 0, -0.02, 0.54);
    for (const sd of [-1, 1]) {
      put(hp, box(0.1, 0.12, 0.05, G(0xFF6FC8, 3)), sd * 0.2, 0.06, 0.32);
      const ear = pivot(hp, sd * 0.18, 0.25, -0.05);
      put(ear, box(0.16, 0.85, 0.1, white), 0, 0.42, 0);
      put(ear, box(0.08, 0.6, 0.11, pink), 0, 0.42, 0.01);
      ear.rotation.set(-1.15, 0, sd * -0.35);
      sway(anim, ear, 'x', 0.06, 1.7, sd);
    }
    const r = rng(161);
    const grow = (parent, p, dir, len, depth) => {
      const e = p.clone().add(dir.clone().multiplyScalar(len));
      parent.add(limb(p, e, 0.045 * (depth + 1) * 0.6, 0.03 * (depth + 0.6) * 0.6, branch, 4));
      if (depth === 0) {
        for (let k = 0; k < 5; k++) {
          const b = put(parent, box(0.11, 0.11, 0.11, pink), e.x + (r() - 0.5) * 0.25, e.y + (r() - 0.5) * 0.2, e.z + (r() - 0.5) * 0.25, r() * 3, r() * 3, 0);
          b.castShadow = false;
        }
        if (r() < 0.5) put(parent, new T.Mesh(new T.OctahedronGeometry(0.06, 0), G(0xFFE27A, 3)), e.x, e.y + 0.12, e.z);
        return;
      }
      for (let k = 0; k < 2; k++) {
        const nd = dir.clone().add(V((r() - 0.5) * 1.3, 0.1 + r() * 0.3, (r() - 0.5) * 1.3)).normalize();
        grow(parent, e, nd, len * 0.72, depth - 1);
      }
    };
    for (const sd of [-1, 1]) grow(hp, V(sd * 0.18, 0.3, 0.05), V(sd * 0.45, 1, 0.1).normalize(), 0.55, 4);
    const hl = halo(0.42, 0xFFE27A, 0.035, 36); put(hp, hl, 0, 0.62, 0.0, Math.PI / 2 - 0.15, 0, 0);
    bob(anim, hl, 0.05, 1.5);
    sway(anim, hp, 'y', 0.12, 0.7);
    return root;
  }
};

/* ============ STORM EGG ============ */

// 7. STORM FOX — cobalt three-tailed fox with lightning cracks
P.stormFox = {
  name: 'Storm Fox', theme: 'storm', glow: 0xFFE45C, rim: 0x5BC8FF, rim2: 0xFFE45C, seed: 17,
  fx: [{ n: 34, kind: 'rise', color: 0xFFF08A, radius: 2, height: 3.5, size: 0.06, speed: 0.8, k: 3 }],
  build({ anim }) {
    const root = new T.Group();
    const skin = M(0x24357F, { r: 0.45, m: 0.1 }), dark = M(0x141E4F, { r: 0.55 }), light = M(0xDCE6FF, { r: 0.5 });
    const bolt = G(0xFFE45C, 2.4), bolt2 = G(0x7FDBFF, 2.2);
    const q = quad({ mat: skin, belly: light, legH: 0.7, H: 0.5, W: 0.48, L: 2.0, seed: 170, legMat: dark, pawMat: dark });
    root.add(q.g);
    const head = beastHead({ mat: skin, muzzle: light, jawMat: dark, eye: 0xFFF28A, snout: 0.55, earH: 0.68, earR: 0.21, earInner: G(0xFFE45C, 1.1), s: 1.0, jawOpen: 0.3, seed: 171 });
    q.headPivot.add(head); q.headPivot.rotation.set(-0.06, 0.25, 0);
    sway(anim, q.headPivot, 'y', 0.14, 0.75);
    for (const sd of [-1, 1]) head.add(tube([V(sd * 0.08, 0.2, 0.36), V(sd * 0.2, 0.26, 0.3), V(sd * 0.27, 0.22, 0.22), V(sd * 0.4, 0.3, 0.12)], () => 0.018, bolt, { seg: 3, steps: 8, tension: 0 }));
    cracks(q.torso, 6, bolt, { seed: 172, w: 0.02, step: 1.6 }); cracks(q.chest, 4, bolt2, { seed: 173, w: 0.02, step: 1.6 }); cracks(q.hips, 4, bolt, { seed: 174, w: 0.02, step: 1.6 });
    flicker(anim, bolt, 0.25, 9);
    const tails = [];
    for (let i = -1; i <= 1; i++) {
      const tp = pivot(q.tailPivot, 0, 0, 0);
      const tl = tail([V(0, 0, 0), V(i * 0.35, 0.35, -0.55), V(i * 0.85, 0.95, -0.9), V(i * 1.05, 1.5, -0.7)], 0.3, skin, { pow: 0.45, rEnd: 0.05 });
      tp.add(tl);
      put(tp, blob(0.2, 0.32, 0.2, light, { seed: 175 + i }), i * 1.05, 1.55, -0.7);
      put(tp, crystal(0.08, 0.35, M(0xFFF08A, { e: 0xFFE45C, ei: 1.0 }), 4), i * 1.05, 1.75, -0.7);
      sway(anim, tp, 'z', 0.12, 1.4, i);
      tails.push(tp);
    }
    breathe(anim, q.chest, 0.025, 2.0);
    return root;
  }
};

// 9. CRYSTAL OTTER — long violet otter carrying crystal clusters
P.crystalOtter = {
  name: 'Crystal Otter', theme: 'storm', glow: 0xC08BFF, rim: 0xB07AFF, rim2: 0x6FD6FF, seed: 19, pedCrystals: 0xA06BFF,
  fx: [{ n: 30, kind: 'rise', color: 0xD7B8FF, radius: 2, height: 3, size: 0.06, speed: 0.4 }],
  build({ anim }) {
    const root = new T.Group();
    const skin = M(0x4B3A8C, { r: 0.5 }), dark = M(0x2C2160, { r: 0.55 }), belly = M(0xB9A6F0, { r: 0.5 });
    const cry = M(0xB48CFF, { r: 0.08, m: 0.15, e: 0x8B4DFF, ei: 0.55, op: 0.88 }), cry2 = M(0x8FE6FF, { r: 0.08, e: 0x4FC8FF, ei: 0.55, op: 0.88 });
    const q = quad({ mat: skin, belly, legH: 0.42, H: 0.46, W: 0.5, L: 2.3, seed: 190, legMat: dark, pawMat: dark });
    root.add(q.g);
    const head = beastHead({ mat: skin, muzzle: belly, jawMat: dark, eye: 0xE2CCFF, snout: 0.32, earH: 0.2, earR: 0.12, whiskers: M(0xFFFFFF, { r: 0.4 }), s: 1.0, jawOpen: 0.15, seed: 191 });
    q.headPivot.add(head); q.headPivot.rotation.set(-0.15, 0.3, 0);
    sway(anim, q.headPivot, 'y', 0.15, 0.8);
    const r = rng(192);
    const cluster = (x, y, z, n, s) => { for (let i = 0; i < n; i++) { const c = crystal((0.1 + r() * 0.06) * s, (0.5 + r() * 0.6) * s, r() < 0.7 ? cry : cry2, 5); put(q.g, c, x + (r() - 0.5) * 0.3 * s, y, z + (r() - 0.5) * 0.4 * s, (r() - 0.5) * 0.9, r() * 3, (r() - 0.5) * 0.9 - 0.2); } };
    cluster(0, q.y + 0.4, 0.55, 6, 1.1); cluster(0, q.y + 0.38, -0.2, 7, 1.3); cluster(0, q.y + 0.35, -0.85, 5, 0.9);
    cracks(q.torso, 5, G(0xC9A2FF, 1.8), { seed: 193, w: 0.016 });
    const tl = tail([V(0, 0, 0), V(0, -0.1, -0.6), V(0, -0.25, -1.2)], 0.3, skin);
    q.tailPivot.add(tl);
    put(q.tailPivot, blob(0.32, 0.08, 0.6, dark, { seed: 194 }), 0, -0.3, -1.45);
    put(q.tailPivot, crystal(0.1, 0.5, cry, 5), 0, -0.22, -1.3, -0.6, 0, 0);
    sway(anim, q.tailPivot, 'y', 0.2, 1.2);
    breathe(anim, q.chest, 0.02, 1.8);
    return root;
  }
};

// 10. ROCKET RINGTAIL — armoured raccoon with a rocket-thruster tail
P.rocketRingtail = {
  name: 'Rocket Ringtail', theme: 'storm', glow: 0xFF6A3D, rim: 0xFF7A3D, rim2: 0x6FB8FF, seed: 20,
  fx: [{ n: 26, kind: 'rise', color: 0xFFB36A, radius: 1.8, height: 3, size: 0.06, speed: 0.7 }],
  build({ anim }) {
    const root = new T.Group();
    const fur = M(0x5F6478, { r: 0.6 }), dark = M(0x2A2D3A, { r: 0.6 }), light = M(0xC9CCD8, { r: 0.55 });
    const armor = M(0xC8382F, { m: 0.55, r: 0.35 }), metal = M(0x8A8F9E, { m: 0.8, r: 0.3 }), gold = GOLD();
    const q = quad({ mat: fur, belly: light, legH: 0.6, H: 0.55, W: 0.55, L: 1.8, seed: 200, legMat: dark, pawMat: dark, band: gold });
    root.add(q.g);
    const head = beastHead({ mat: fur, muzzle: light, jawMat: dark, eye: 0xFFB34A, snout: 0.36, earH: 0.32, earR: 0.17, earInner: dark, whiskers: light, s: 1.05, jawOpen: 0.2, seed: 201 });
    put(head, blob(0.42, 0.11, 0.2, dark, { d: 1, seed: 202 }), 0, 0.06, 0.27);
    for (const sd of [-1, 1]) put(head, new T.Mesh(new T.TorusGeometry(0.11, 0.025, 4, 8), gold), sd * 0.2, 0.06, 0.38, 0, sd * 0.4, 0);
    q.headPivot.add(head); q.headPivot.rotation.set(-0.08, 0.22, 0);
    sway(anim, q.headPivot, 'y', 0.13, 0.85);
    put(q.g, box(1.0, 0.18, 0.7, armor, { j: 0.04 }), 0, q.y + 0.56, 0.3, -0.12, 0, 0);
    put(q.g, box(0.9, 0.16, 0.6, armor, { j: 0.04 }), 0, q.y + 0.52, -0.35, 0.08, 0, 0);
    for (const sd of [-1, 1]) put(q.g, box(0.2, 0.42, 0.5, armor, { j: 0.04 }), sd * 0.58, q.y + 0.3, 0.6, 0, 0, sd * 0.25);
    for (let i = 0; i < 4; i++) put(q.g, new T.Mesh(new T.OctahedronGeometry(0.04, 0), gold), -0.3 + i * 0.2, q.y + 0.66, 0.3);
    const tl = tail([V(0, 0, 0), V(0, 0.35, -0.55), V(0, 0.85, -0.85), V(0, 1.25, -0.8)], 0.27, fur, { pow: 0.3, rEnd: 0.12 });
    q.tailPivot.add(tl);
    for (let i = 1; i < 6; i++) band(q.tailPivot, tl.userData.curve, i / 6.5, 0.27 * Math.pow(1 - i / 6.5, 0.3) + 0.12, dark, { th: 0.07 });
    const nz = pivot(q.tailPivot, 0, 1.25, -0.8);
    put(nz, new T.Mesh(new T.CylinderGeometry(0.17, 0.26, 0.32, 8, 1, true), metal), 0, 0.12, 0);
    put(nz, new T.Mesh(new T.TorusGeometry(0.26, 0.04, 4, 8), gold), 0, 0.28, 0, Math.PI / 2, 0, 0);
    const fl1 = G(0xFF6A1F, 2.6, { add: true, op: 0.9 }), fl2 = G(0xFFE07A, 3, { add: true, op: 0.9 });
    const flame = put(nz, new T.Mesh(new T.ConeGeometry(0.2, 0.9, 7, 1, true), fl1), 0, 0.75, 0);
    const core = put(nz, new T.Mesh(new T.ConeGeometry(0.1, 0.55, 6, 1, true), fl2), 0, 0.58, 0);
    anim.push(t => { const k = 1 + Math.sin(t * 23) * 0.12 + Math.sin(t * 37) * 0.08; flame.scale.set(1, k, 1); core.scale.set(1, 2 - k, 1); });
    nz.rotation.x = 0.0;
    sway(anim, q.tailPivot, 'z', 0.08, 1.5);
    breathe(anim, q.chest, 0.025, 2.0);
    return root;
  }
};

/* ============ COSMIC EGG ============ */

// 12. NEON WYVERN — black wyvern with neon energy wings
P.neonWyvern = {
  name: 'Neon Wyvern', theme: 'cosmic', glow: 0xC24BFF, rim: 0xD06CFF, rim2: 0x5B3BFF, seed: 21, bloom: 0.85,
  fx: [{ n: 40, kind: 'rise', color: 0xE09BFF, radius: 2.4, height: 4, size: 0.06, speed: 0.6, k: 3 }],
  build({ anim }) {
    const root = new T.Group();
    const skin = M(0x1D1730, { r: 0.4, m: 0.25 }), skin2 = M(0x2E2350, { r: 0.45 });
    const neon = G(0xD06CFF, 2.4), mem = M(0xB040FF, { e: 0x9B2BFF, ei: 1.1, op: 0.72, r: 0.3, dw: false });
    const g = new T.Group(); root.add(g);
    for (const sd of [-1, 1]) {
      put(g, blob(0.3, 0.45, 0.4, skin, { seed: 210 + sd }), sd * 0.38, 1.05, -0.1);
      g.add(limb(V(sd * 0.4, 0.9, -0.05), V(sd * 0.45, 0.45, 0.25), 0.15, 0.1, skin, 6));
      g.add(limb(V(sd * 0.45, 0.45, 0.25), V(sd * 0.46, 0.08, 0.0), 0.1, 0.08, skin, 6));
      put(g, blob(0.15, 0.08, 0.24, skin2, { d: 0, seed: 213 }), sd * 0.46, 0.08, 0.12);
      for (let k = -1; k <= 1; k++) put(g, aim(spike(0.03, 0.18, BONE(), 4), V(k * 0.35, -0.3, 1)), sd * 0.46 + k * 0.07, 0.06, 0.32);
    }
    const body = put(g, blob(0.62, 0.66, 0.95, skin, { seed: 214 }), 0, 1.45, 0, -0.35, 0, 0);
    put(g, blob(0.42, 0.4, 0.6, skin2, { seed: 215 }), 0, 1.3, 0.3, -0.4, 0, 0);
    const neck = tube([V(0, 1.7, 0.55), V(0, 2.25, 0.85), V(0, 2.75, 1.0)], t => 0.32 - t * 0.12, skin, { seg: 7, steps: 16 });
    g.add(neck);
    const hp = pivot(g, 0, 2.85, 1.1);
    const head = dragonHead({ mat: skin, jawMat: skin2, eye: 0xFF7AF5, s: 1.0, hornMat: skin2, crest: M(0xD06CFF, { e: 0xB040FF, ei: 1.2 }), jawOpen: 0.5, seed: 216 });
    hp.add(head); hp.rotation.set(0.1, 0.15, 0);
    sway(anim, hp, 'y', 0.15, 0.7); sway(anim, head.userData.jaw, 'x', 0.1, 1.5);
    cracks(body, 9, neon, { seed: 217, w: 0.022 }); cracks(neck, 4, neon, { seed: 218, w: 0.018, yMin: -0.9, yMax: 0.9 });
    const spine = new T.CatmullRomCurve3([V(0, 2.6, 1.0), V(0, 2.0, 0.7), V(0, 1.95, -0.1), V(0, 1.6, -0.8)]);
    spikeRow(g, spine, 9, M(0xD06CFF, { e: 0xB040FF, ei: 1.0, r: 0.3 }), { h: 0.3, r: 0.06, off: 0.18, back: 1 });
    for (const sd of [-1, 1]) {
      const wp = pivot(g, sd * 0.4, 1.9, 0.2);
      wp.add(batWing({ bone: skin2, membrane: mem, s: 1.35, side: sd }));
      wp.rotation.set(0.1, sd * 0.3, sd * 0.85);
      sway(anim, wp, 'z', 0.22 * sd, 1.9);
    }
    const tl = tail([V(0, 1.1, -0.8), V(0, 0.7, -1.5), V(0.6, 0.35, -2.1), V(1.4, 0.3, -2.3), V(2.0, 0.45, -2.0)], 0.3, skin);
    g.add(tl);
    put(g, crystal(0.14, 0.7, M(0xD06CFF, { e: 0xB040FF, ei: 1.3, r: 0.2 }), 4), 2.0, 0.45, -2.0, 0, 0, -1.4);
    breathe(anim, body, 0.02, 1.8);
    return root;
  }
};

// 13. SOLAR MANTA — golden floating manta with a sun corona
P.solarManta = {
  name: 'Solar Manta', theme: 'cosmic', glow: 0xFFC23A, rim: 0xFFB13D, rim2: 0xFF6A9B, seed: 22, lift: 0.9, bloom: 0.5,
  fx: [{ n: 40, kind: 'orbit', color: 0xFFD66A, radius: 2.6, height: 2.5, size: 0.07, speed: 0.5, k: 3, y0: 0.8 }],
  build({ anim }) {
    const root = new T.Group();
    const gold = M(0xE6A12A, { m: 0.45, r: 0.35 }), under = M(0xFFF0C4, { r: 0.5 }), dark = M(0x8A4A10, { r: 0.5 });
    const sun = G(0xFFC23A, 1.9), sun2 = G(0xFF8A3D, 1.8);
    const g = pivot(root, 0, 1.25, 0); g.rotation.x = 0.42;
    const body = put(g, blob(0.95, 0.34, 1.25, gold, { seed: 220 }), 0, 0, 0);
    put(g, blob(0.8, 0.2, 1.05, under, { seed: 221 }), 0, -0.14, 0);
    for (const sd of [-1, 1]) {
      const wp = pivot(g, sd * 0.7, 0, 0);
      put(wp, blob(1.25, 0.14, 0.75, gold, { seed: 222 + sd }), sd * 0.95, 0.02, -0.15, 0, sd * 0.35, sd * -0.05);
      put(wp, aim(spike(0.18, 0.9, gold, 4), V(sd, 0.15, -0.55)), sd * 1.9, 0.0, -0.4).scale.set(1, 1, 0.3);
      sway(anim, wp, 'z', 0.25 * sd, 1.6);
      g.add(tube([V(sd * 0.35, 0.0, 1.05), V(sd * 0.55, 0.05, 1.45), V(sd * 0.42, 0.25, 1.65), V(sd * 0.26, 0.2, 1.5)], t => 0.1 * (1 - t) + 0.02, dark, { seg: 5, steps: 12 }));
      put(g, glowEye(0xFFF6C8, 0.1, 0.05, 0.07), sd * 0.42, 0.18, 0.92, 0, sd * 0.3, sd * -0.2);
    }
    g.add(tube([V(0, 0, -1.2), V(0, 0.1, -2.0), V(0.2, 0.0, -2.8), V(0.5, -0.2, -3.3)], t => 0.08 * (1 - t) + 0.01, dark, { seg: 4, steps: 16 }));
    put(g, new T.Mesh(new T.OctahedronGeometry(0.1, 0), sun), 0.5, -0.2, -3.3);
    cracks(body, 5, sun, { seed: 224, w: 0.016, yMin: 0.3, yMax: 0.95 });
    const crown = pivot(root, 0, 1.6, -0.9); crown.rotation.x = Math.PI / 2 - 0.2;
    for (let i = 0; i < 16; i++) {
      const a = i / 16 * Math.PI * 2;
      const s = spike(0.07, 0.55 + (i % 2) * 0.35, i % 2 ? sun : sun2, 4);
      put(crown, s, Math.cos(a) * 1.35, 0, Math.sin(a) * 1.35);
      aim(s, V(Math.cos(a), 0.15, Math.sin(a)));
    }
    put(crown, new T.Mesh(new T.TorusGeometry(1.3, 0.03, 4, 64), sun), 0, 0, 0, Math.PI / 2, 0, 0); put(crown, new T.Mesh(new T.CircleGeometry(1.25, 48), G(0xFF9A2B, 0.5, { op: 0.35, add: true })), 0, 0, 0, Math.PI / 2, 0, 0);
    anim.push((t, dt) => { crown.rotation.y += dt * 0.25; });
    bob(anim, crown, 0.12, 1.1);
    bob(anim, g, 0.12, 1.1); sway(anim, g, 'z', 0.06, 0.9);
    return root;
  }
};

// 14. THUNDER HYDRA — three-headed storm dragon
P.thunderHydra = {
  name: 'Thunder Hydra', theme: 'cosmic', glow: 0xFFE14A, rim: 0x6F8BFF, rim2: 0xFFE14A, seed: 23,
  fx: [{ n: 36, kind: 'rise', color: 0xFFF08A, radius: 2.4, height: 4, size: 0.06, speed: 0.9, k: 3 }],
  build({ anim }) {
    const root = new T.Group();
    const skin = M(0x26318A, { r: 0.45, m: 0.15 }), dark = M(0x161C52, { r: 0.55 }), belly = M(0xF2C65A, { r: 0.45 });
    const bolt = G(0xFFE14A, 2.4);
    const q = quad({ mat: skin, belly, legH: 0.62, H: 0.62, W: 0.66, L: 2.0, seed: 230, legMat: dark, pawMat: dark, headPos: V(0, 1.95, 0.95) });
    root.add(q.g);
    const heads = [[-0.75, 2.75, 1.25, 0.8, -0.3], [0, 3.15, 1.4, 0.92, 0], [0.75, 2.75, 1.25, 0.8, 0.3]];
    heads.forEach(([x, y, z, s, ry], i) => {
      q.g.add(tube([V(0, 1.75, 0.75), V(x * 0.5, y * 0.8, z * 0.85), V(x, y, z)], t => 0.3 - t * 0.12, skin, { seg: 7, steps: 16 }));
      const hp = pivot(q.g, x, y, z);
      const h = dragonHead({ mat: skin, jawMat: dark, eye: 0xFFF08A, s, hornMat: belly, jawOpen: 0.35 + i * 0.08, seed: 231 + i });
      hp.add(h); hp.rotation.set(0.1, ry, 0);
      sway(anim, hp, 'y', 0.12, 0.8, i * 2); sway(anim, hp, 'x', 0.06, 1.3, i);
    });
    [q.torso, q.chest, q.hips].forEach((b, i) => cracks(b, 6, bolt, { seed: 236 + i, w: 0.022, step: 1.7 }));
    flicker(anim, bolt, 0.3, 11);
    const spine = new T.CatmullRomCurve3([V(0, q.y + 0.8, 0.6), V(0, q.y + 0.68, -0.1), V(0, q.y + 0.55, -0.8)]);
    spikeRow(q.g, spine, 7, M(0xFFE14A, { e: 0xFFC21A, ei: 0.9, r: 0.3 }), { h: 0.38, r: 0.09, off: -0.04, crystal: true });
    for (const sd of [-1, 1]) {
      const wp = pivot(q.g, sd * 0.45, q.y + 0.6, 0.3);
      wp.add(batWing({ bone: dark, membrane: M(0x3A4BC8, { e: 0x2B3BFF, ei: 0.25, op: 0.85, dw: false }), s: 0.7, side: sd }));
      wp.rotation.set(0, sd * 0.3, sd * 0.6); sway(anim, wp, 'z', 0.15 * sd, 2.0);
    }
    const tl = tail([V(0, 0, 0), V(0, -0.1, -0.8), V(0.5, -0.3, -1.5), V(1.2, -0.5, -1.8)], 0.32, skin);
    q.tailPivot.add(tl); sway(anim, q.tailPivot, 'y', 0.15, 1.2);
    breathe(anim, q.chest, 0.02, 1.7);
    return root;
  }
};

// 15. QUANTUM PHOENIX — cyan/magenta plasma phoenix with long tail plumes
P.quantumPhoenix = {
  name: 'Quantum Phoenix', theme: 'cosmic', glow: 0xFF4FD8, rim: 0x37F4FF, rim2: 0xEB62FF, seed: 24, bloom: 0.9,
  fx: [{ n: 50, kind: 'rise', color: 0x9BF7FF, radius: 2.2, height: 4.5, size: 0.06, speed: 0.7, k: 3 }, { n: 30, kind: 'rise', color: 0xFF8FE8, radius: 2.2, height: 4.5, size: 0.06, speed: 0.5, k: 3, seed: 5 }],
  build({ anim }) {
    const root = new T.Group();
    const skin = M(0x2A1A5E, { r: 0.4, m: 0.2 }), chestM = M(0x7A2BB8, { r: 0.4, e: 0x5A1A9E, ei: 0.4 }), gold = GOLD();
    const plume = G(0xffffff, 1.9, { vc: true });
    const g = new T.Group(); root.add(g);
    for (const sd of [-1, 1]) {
      g.add(limb(V(sd * 0.25, 1.0, 0), V(sd * 0.3, 0.45, 0.12), 0.1, 0.06, gold, 5));
      g.add(limb(V(sd * 0.3, 0.45, 0.12), V(sd * 0.32, 0.08, 0.05), 0.06, 0.045, gold, 5));
      for (let k = -1; k <= 1; k++) put(g, aim(spike(0.03, 0.26, BONE(), 4), V(k * 0.4, -0.15, 1)), sd * 0.32, 0.06, 0.08);
    }
    const body = put(g, blob(0.72, 0.9, 0.75, skin, { seed: 240 }), 0, 1.45, 0, -0.25, 0, 0);
    put(g, blob(0.55, 0.65, 0.4, chestM, { seed: 241 }), 0, 1.45, 0.32, -0.2, 0, 0);
    g.add(tube([V(0, 1.9, 0.2), V(0, 2.3, 0.4), V(0, 2.55, 0.5)], t => 0.22 - t * 0.06, skin, { seg: 6, steps: 10 }));
    const hp = pivot(g, 0, 2.62, 0.55);
    put(hp, blob(0.3, 0.3, 0.34, skin, { seed: 242 }), 0, 0, 0);
    put(hp, aim(spike(0.09, 0.42, gold, 4), V(0, -0.4, 1)), 0, -0.03, 0.26);
    for (const sd of [-1, 1]) put(hp, glowEye(0x9BF7FF, 0.08, 0.035, 0.06), sd * 0.17, 0.06, 0.24, 0, sd * 0.4, sd * -0.35);
    for (let i = 0; i < 5; i++) {
      const a = (i - 2) * 0.25;
      hp.add(tube([V(Math.sin(a) * 0.1, 0.2, -0.05), V(Math.sin(a) * 0.35, 0.65, -0.4), V(Math.sin(a) * 0.6, 0.85, -0.95)], t => 0.06 * (1 - t) + 0.008, plume,
        { seg: 4, steps: 12, colorFn: vc(0x37F4FF, 0xEB62FF) }));
    }
    sway(anim, hp, 'y', 0.18, 0.7);
    cracks(body, 8, G(0x37F4FF, 2.0), { seed: 243, w: 0.018 });
    for (const sd of [-1, 1]) {
      const wp = pivot(g, sd * 0.4, 1.85, -0.05);
      wp.add(featherWing({ base: skin, covert: chestM, c1: 0x1FB8D0, c2: 0xB83BD8, tipGlow: 0xFF8FF0, glow: true, glowK: 0.45, s: 1.05, side: sd, n: 16, len: 1.0 }));
      wp.rotation.set(0.15, sd * 0.3, sd * 0.45);
      sway(anim, wp, 'z', 0.2 * sd, 1.7);
    }
    for (let i = 0; i < 5; i++) {
      const a = (i - 2) * 0.28;
      const pl = tube([V(0, 1.05, -0.45), V(Math.sin(a) * 0.4, 0.75, -1.1), V(Math.sin(a) * 0.9, 0.45, -1.9), V(Math.sin(a) * 1.4, 0.55, -2.7)], t => 0.1 * (1 - t) + 0.015, plume,
        { seg: 4, steps: 22, colorFn: (t) => new T.Color(0x37F4FF).lerp(new T.Color(0xEB62FF), t).multiplyScalar(0.6 + t * 0.6) });
      g.add(pl);
      put(g, new T.Mesh(new T.OctahedronGeometry(0.08, 0), G(0xEB62FF, 3)), Math.sin(a) * 1.4, 0.55, -2.7);
    }
    breathe(anim, body, 0.025, 2.0);
    return root;
  }
};

// 16. COSMIC LEVIATHAN — floating space whale-dragon with constellations
P.cosmicLeviathan = {
  name: 'Cosmic Leviathan', theme: 'cosmic', glow: 0x8C7BFF, rim: 0x9C7BFF, rim2: 0x37F4FF, seed: 25, lift: 0.3,
  fx: [{ n: 70, kind: 'orbit', color: 0xC9B8FF, radius: 3.2, height: 3.5, size: 0.06, speed: 0.3, k: 3, y0: 0.5 }, { n: 25, kind: 'orbit', color: 0xFF8FD8, radius: 2.6, height: 3, size: 0.09, speed: 0.2, k: 2, y0: 0.8, seed: 9 }],
  build({ anim }) {
    const root = new T.Group();
    const g = pivot(root, 0, 0, 0);
    const pts = [V(0, 1.75, 1.9), V(0, 1.7, 1.1), V(0.1, 1.6, 0.1), V(-0.15, 1.7, -0.9), V(0.1, 1.95, -1.8), V(0.35, 2.3, -2.4)];
    const rF = t => t < 0.18 ? 0.45 + Math.sin(t / 0.18 * Math.PI * 0.5) * 0.4 : 0.85 * Math.pow(Math.max(0, 1 - (t - 0.18) / 0.82), 0.9) + 0.06;
    const body = serpentBody(pts, rF, 0x2A2380, 0xA49BFF, { seg: 9, steps: 70 });
    g.add(body);
    const curve = body.userData.curve;
    const dark = M(0x1B164F, { r: 0.5 }), fin = M(0x3A2FA8, { r: 0.45, e: 0x4B3BFF, ei: 0.2 });
    for (const sd of [-1, 1]) {
      put(g, glowEye(0xC9F4FF, 0.11, 0.05, 0.08), sd * 0.48, 1.9, 1.55, 0, sd * 0.7, sd * -0.3);
      put(g, blob(0.75, 0.08, 0.38, fin, { seed: 251 + sd }), sd * 0.95, 1.45, 0.65, 0.2, sd * -0.5, sd * -0.35);
      put(g, blob(0.55, 0.06, 0.28, fin, { seed: 253 + sd }), sd * 0.55, 2.4, -2.55, 0, sd * 0.7, sd * 0.2);
      g.add(tube([V(sd * 0.3, 2.2, 1.3), V(sd * 0.55, 2.5, 0.9), V(sd * 0.6, 2.6, 0.45), V(sd * 0.45, 2.45, 0.25)], t => 0.08 * (1 - t) + 0.01, BONE(), { seg: 5, steps: 12 }));
      for (let k = 0; k < 2; k++) g.add(tube([V(sd * 0.2, 1.45, 2.05), V(sd * (0.45 + k * 0.1), 1.3 - k * 0.1, 2.25), V(sd * (0.7 + k * 0.15), 1.05 - k * 0.15, 2.1)], t => 0.025 * (1 - t) + 0.006, G(0xC9B8FF, 1.6), { seg: 3, steps: 8 }));
    }
    for (let i = 0; i < 6; i++) put(g, box(0.5 - i * 0.03, 0.025, 0.02, M(0x6B60D8, { r: 0.5 })), 0, 1.3 - i * 0.02, 1.7 - i * 0.28).visible = true;
    const star = G(0xFFFFFF, 2.4), line = G(0xB9A8FF, 1.2);
    const sp = [];
    const r = rng(256);
    for (let i = 0; i < 13; i++) {
      const u = 0.1 + i * 0.058, p = curve.getPointAt(u);
      const ang = (r() - 0.5) * 1.6; const off = V(Math.sin(ang) * rF(u) * 0.95, Math.cos(ang) * rF(u) * 0.95, 0);
      const pt = p.clone().add(off);
      sp.push(pt);
      const s = put(g, new T.Mesh(new T.OctahedronGeometry(0.05 + r() * 0.04, 0), star), pt.x, pt.y, pt.z);
      s.userData.ph = r() * 6;
      anim.push(t => s.scale.setScalar(0.8 + Math.sin(t * 3 + s.userData.ph) * 0.35));
    }
    for (let i = 0; i < sp.length - 1; i++) g.add(tube([sp[i], sp[i].clone().lerp(sp[i + 1], 0.5), sp[i + 1]], () => 0.008, line, { seg: 3, steps: 2 }));
    spikeRow(g, curve, 8, fin, { h: 0.28, r: 0.07, off: 0.0, from: 0.3, to: 0.9, back: 1.2, hFn: u => 1.2 - u });
    const tailEnd = curve.getPointAt(1);
    for (const sd of [-1, 1]) put(g, blob(0.7, 0.07, 0.35, fin, { seed: 257 + sd }), tailEnd.x + sd * 0.55, tailEnd.y + 0.05, tailEnd.z - 0.1, 0, sd * 0.5, sd * 0.25);
    bob(anim, g, 0.12, 0.9); sway(anim, g, 'z', 0.05, 0.7); sway(anim, g, 'y', 0.06, 0.5);
    return root;
  }
};

L.ORDER = ['mallow', 'puddlePup', 'aeroKitty', 'leafGecko', 'emberChick', 'starBunny', 'stormFox', 'cloudSerpent', 'crystalOtter', 'rocketRingtail', 'auroraLynx', 'neonWyvern', 'solarManta', 'thunderHydra', 'quantumPhoenix', 'cosmicLeviathan'];
})();
/* LAUNCH YOUR MONSTER! — ring flight scene: a monster flies a loop through glowing rings */
(function () {
'use strict';
const T = window.THREE, L = window.LYM;
const { V, M, G, blob, put, rng, particles } = L;

function skyTex() {
  const c = document.createElement('canvas'); c.width = 4; c.height = 256;
  const x = c.getContext('2d'); const g = x.createLinearGradient(0, 0, 0, 256);
  g.addColorStop(0, '#14205A'); g.addColorStop(0.45, '#4B3B9A'); g.addColorStop(0.75, '#E0708A'); g.addColorStop(1, '#FFC07A');
  x.fillStyle = g; x.fillRect(0, 0, 4, 256);
  const t = new T.CanvasTexture(c); t.colorSpace = T.SRGBColorSpace; return t;
}

L.buildFlight = function (petId, w, h) {
  const def = L.PETS[petId];
  const scene = new T.Scene();
  scene.background = skyTex();
  scene.fog = new T.Fog(0x8A5FA8, 30, 95);
  scene.add(new T.HemisphereLight(0xFFD6B0, 0x2A1E5A, 0.7));
  const sun = new T.DirectionalLight(0xFFE2C0, 2.4); sun.position.set(-10, 14, 8); scene.add(sun);
  const rimL = new T.DirectionalLight(def.rim ?? def.glow, 2.2); rimL.position.set(8, 5, -10); scene.add(rimL);

  // loop path through ring gates
  const gates = [V(0, 8, 22), V(16, 10.5, 10), V(18, 7, -10), V(2, 11, -20), V(-16, 7.5, -8), V(-15, 9.5, 12)];
  const path = new T.CatmullRomCurve3(gates, true, 'centripetal');
  const rings = gates.map((p, i) => {
    const u = i / gates.length, tg = path.getTangentAt(u);
    const col = i % 2 ? 0x37F4FF : 0xFFCF55;
    const mat = G(col, 2.0);
    const grp = new T.Group(); grp.position.copy(path.getPointAt(u));
    grp.lookAt(grp.position.clone().add(tg));
    const ring = new T.Mesh(new T.TorusGeometry(2.1, 0.14, 6, 40), mat); grp.add(ring);
    const outer = new T.Mesh(new T.TorusGeometry(2.45, 0.05, 4, 40), G(col, 1.2)); grp.add(outer);
    for (let k = 0; k < 8; k++) {
      const a = k / 8 * Math.PI * 2, s = new T.Mesh(new T.OctahedronGeometry(0.16, 0), M(0xE8B13A, { m: 0.8, r: 0.3 }));
      s.position.set(Math.cos(a) * 2.1, Math.sin(a) * 2.1, 0); grp.add(s);
    }
    scene.add(grp);
    return { grp, mat, base: mat.color.clone(), flash: 0, u };
  });

  // floating islands + clouds
  const r = rng(77);
  const rock = M(0x6A5A8A, { r: 0.9 }), grass = M(0x6CC06A, { r: 0.8 }), cloud = M(0xFFE9F2, { r: 1, e: 0xFFB8C8, ei: 0.15 });
  for (let i = 0; i < 9; i++) {
    const a = i / 9 * Math.PI * 2 + r(), d = 12 + r() * 16, y = -2 + r() * 6, s = 1.5 + r() * 2.8;
    const isl = new T.Group(); isl.position.set(Math.cos(a) * d, y, Math.sin(a) * d);
    put(isl, blob(s, s * 0.35, s, grass, { d: 1, j: 0.18, seed: i }), 0, 0, 0);
    put(isl, blob(s * 0.92, s * 1.1, s * 0.92, rock, { d: 1, j: 0.25, seed: i + 30 }), 0, -s * 0.85, 0);
    put(isl, blob(s * 0.5, s * 0.7, s * 0.5, rock, { d: 0, j: 0.25, seed: i + 60 }), s * 0.2, -s * 1.9, -s * 0.1);
    scene.add(isl);
  }
  for (let i = 0; i < 14; i++) {
    const cl = new T.Group(); const a = r() * Math.PI * 2, d = 20 + r() * 30;
    cl.position.set(Math.cos(a) * d, 2 + r() * 14, Math.sin(a) * d);
    for (let k = 0; k < 5; k++) put(cl, blob(1.4 + r() * 1.6, 0.8 + r() * 0.6, 1.2 + r() * 1.4, cloud, { d: 1, j: 0.2, seed: i * 9 + k }), (r() - 0.5) * 4, r() * 0.8, (r() - 0.5) * 3);
    scene.add(cl);
  }
  const sparks = particles(160, { color: 0xFFE2B0, radius: 34, height: 20, y0: -2, size: 0.18, speed: 0.4, k: 2 });
  scene.add(sparks);

  // the monster (no pedestal)
  const anim = [];
  const petRoot = new T.Group(); scene.add(petRoot);
  const pet = def.build({ anim, def });
  const bb = new T.Box3().setFromObject(pet), ctr = bb.getCenter(V(0, 0, 0)), size = bb.getSize(V(0, 0, 0));
  const sc = 2.6 / Math.max(size.x, size.y, size.z);
  pet.scale.setScalar(sc); pet.position.set(-ctr.x * sc, -ctr.y * sc, -ctr.z * sc);
  const bank = new T.Group(); bank.add(pet); petRoot.add(bank);

  // trail ribbon
  const N = 70, tpos = new Float32Array(N * 2 * 3), tcol = new Float32Array(N * 2 * 3), idx = [];
  for (let i = 0; i < N - 1; i++) { const a = i * 2; idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); }
  const tg = new T.BufferGeometry();
  tg.setAttribute('position', new T.BufferAttribute(tpos, 3)); tg.setAttribute('color', new T.BufferAttribute(tcol, 3)); tg.setIndex(idx);
  const trail = new T.Mesh(tg, new T.MeshBasicMaterial({ vertexColors: true, transparent: true, blending: T.AdditiveBlending, depthWrite: false, side: T.DoubleSide }));
  trail.frustumCulled = false; scene.add(trail);
  const hist = [];
  const tc1 = new T.Color(def.glow).multiplyScalar(0.85), tc2 = new T.Color(0xffffff).multiplyScalar(0.7);

  const cam = new T.PerspectiveCamera(52, w / h, 0.1, 200);
  const camPos = V(0, 12, 30);
  let lastPassed = -1, combo = 0;
  const LOOP = 13; // seconds per lap
  const tmp = V(0, 0, 0);

  function update(t, dt) {
    const u = (((t / LOOP) % 1) + 1) % 1;
    const p = path.getPointAt(u), ahead = path.getPointAt((u + 0.01) % 1), tan = path.getTangentAt(u);
    const tan2 = path.getTangentAt((u + 0.02) % 1);
    petRoot.position.copy(p);
    petRoot.lookAt(ahead);
    const turn = tan.clone().cross(tan2).y;
    bank.rotation.z = T.MathUtils.lerp(bank.rotation.z, -turn * 18, 0.08);
    const sq = 1 + Math.sin(t * 6) * 0.03;
    bank.scale.set(1 / sq, sq, 1);
    // trail
    const lead = petRoot.position.clone().add(tan.clone().multiplyScalar(-0.9));
    if (!hist.length || hist[0].distanceTo(lead) > 0.12) hist.unshift(lead); else hist[0].copy(lead);
    if (hist.length > N) hist.length = N;
    const side = V(0, 1, 0).cross(tan).normalize();
    for (let i = 0; i < N; i++) {
      const q = hist[Math.min(i, hist.length - 1)], k = 1 - i / (N - 1), wdt = 0.32 * Math.pow(k, 0.8);
      const q2 = hist[Math.min(i + 1, hist.length - 1)];
      const dir = q.clone().sub(q2); if (dir.lengthSq() < 1e-6) dir.copy(tan);
      const s2 = dir.cross(cam.position.clone().sub(q)).normalize().multiplyScalar(wdt);
      tpos.set([q.x + s2.x, q.y + s2.y, q.z + s2.z, q.x - s2.x, q.y - s2.y, q.z - s2.z], i * 6);
      const c = tc2.clone().lerp(tc1, Math.min(1, i / (N * 0.3))).multiplyScalar(k * k);
      tcol.set([c.r, c.g, c.b, c.r, c.g, c.b], i * 6);
    }
    tg.attributes.position.needsUpdate = true; tg.attributes.color.needsUpdate = true;
    // ring flashes
    rings.forEach((rg, i) => {
      if (rg.grp.position.distanceTo(p) < 1.2 && lastPassed !== i) { lastPassed = i; rg.flash = 1; combo = (combo % 9) + 1; }
      rg.flash = Math.max(0, rg.flash - dt * 1.6);
      rg.mat.color.copy(rg.base).multiplyScalar(1 + rg.flash * 1.1);
      const s = 1 + rg.flash * 0.35; rg.grp.scale.setScalar(s);
      rg.grp.rotation.z += dt * 0.3;
    });
    // chase camera
    const back = tan.clone().multiplyScalar(-4.2).add(V(0, 2.6, 0)).add(side.clone().multiplyScalar(5.2));
    tmp.copy(p).add(back);
    camPos.copy(tmp);
    cam.position.copy(camPos);
    cam.lookAt(p.clone().add(tan.clone().multiplyScalar(3)));
    sparks.userData.update(t, dt);
  }
  return { flight: true, scene, cam, anim, update, def: Object.assign({}, def, { bloom: 0.55 }), get combo() { return combo; } };
};
})();
window.LYM && window.LYM.start && (document.readyState==='loading' ? document.addEventListener('DOMContentLoaded', ()=>LYM.start()) : LYM.start());
